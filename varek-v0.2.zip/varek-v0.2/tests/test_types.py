"""
tests/test_types.py
────────────────────
VAREK v0.2 — Full type system test suite.
All tests use plain function calls — no walrus or tuple-lambda tricks.
Run: python tests/test_types.py
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from varek.types import (
    TypeVar, PrimType, OptionalType, ArrayType, MapType, TupleType,
    TensorType, ResultType, FunctionType, SchemaType, FieldDef,
    Substitution, Scheme,
    fresh_var, reset_var_counter, reset_dim_counter,
    T_INT, T_FLOAT, T_STR, T_BOOL, T_NIL, Dim,
)
from varek.unify import unify, UnifyError, OccursError, ShapeError
from varek.env   import TypeEnv, SchemaRegistry
from varek.checker import TypeChecker, SchemaValidator
from varek.errors  import Span, VarekError
import varek

# ── Harness ───────────────────────────────────────────────────────

P = 0; F = 0; FAILS = []

def chk(name, fn):
    global P, F
    reset_var_counter(); reset_dim_counter()
    try:
        assert fn() is not False
        print(f"  PASS  {name}"); P += 1
    except Exception as e:
        print(f"  FAIL  {name}: {e}"); F += 1; FAILS.append((name, str(e)))

SPAN = Span("<test>", 1, 1)

def ok(src):
    r = TypeChecker.check(src, "<t>"); assert r.ok, r.report(); return r

def bad(src):
    r = TypeChecker.check(src, "<t>"); assert not r.ok; return r

def xty(src):
    ty, errs = varek.check_expr(src)
    assert ty is not None, errs.report()
    return ty

def uni(a, b):
    return unify(a, b, SPAN)

def uni_fail(a, b):
    try: unify(a, b, SPAN); return False
    except (UnifyError, VarekError): return True

print("\n=== VAREK v0.2 — Type System Test Suite ===\n")

# ════════════════════════════════════════════════════════
print("-- Type Algebra --")
# ════════════════════════════════════════════════════════

chk("prim int",          lambda: T_INT == PrimType("int"))
chk("prim float",        lambda: T_FLOAT == PrimType("float"))
chk("prim str",          lambda: T_STR == PrimType("str"))
chk("prim bool",         lambda: T_BOOL == PrimType("bool"))
chk("prim nil",          lambda: T_NIL == PrimType("nil"))
chk("prim no free vars", lambda: T_INT.free_vars() == frozenset())
chk("prim concrete",     lambda: T_INT.is_concrete())

chk("typevar free vars",     lambda: TypeVar("'a").free_vars() == frozenset({"'a"}))
chk("typevar not concrete",  lambda: not TypeVar("'a").is_concrete())
chk("typevar contains self", lambda: TypeVar("'a").contains_var("'a"))

chk("optional free vars",   lambda: OptionalType(TypeVar("'a")).free_vars() == frozenset({"'a"}))
chk("optional str",         lambda: str(OptionalType(T_INT)) == "int?")
chk("optional concrete",    lambda: OptionalType(T_STR).is_concrete())

chk("array free vars",      lambda: ArrayType(TypeVar("'a")).free_vars() == frozenset({"'a"}))
chk("array str",            lambda: str(ArrayType(T_INT)) == "int[]")

chk("map free vars",        lambda: MapType(TypeVar("'a"), TypeVar("'b")).free_vars() == frozenset({"'a","'b"}))
chk("map str",              lambda: str(MapType(T_STR, T_INT)) == "{str: int}")

chk("tuple free vars",      lambda: TupleType((TypeVar("'a"), T_INT)).free_vars() == frozenset({"'a"}))
chk("tuple str",            lambda: str(TupleType((T_INT, T_STR))) == "(int, str)")

chk("result free vars",     lambda: ResultType(TypeVar("'a")).free_vars() == frozenset({"'a"}))
chk("result str",           lambda: str(ResultType(T_FLOAT)) == "Result<float>")

chk("fn free vars",         lambda: FunctionType((TypeVar("'a"),), TypeVar("'b")).free_vars() == frozenset({"'a","'b"}))
chk("fn str",               lambda: str(FunctionType((T_INT, T_STR), T_BOOL)) == "(int, str) -> bool")

chk("tensor concrete dims", lambda: TensorType(T_FLOAT, (Dim(value=224), Dim(value=224), Dim(value=3))).is_fully_shaped())
chk("tensor symbolic dims", lambda: not TensorType(T_FLOAT, (Dim(var="d0"),)).is_fully_shaped())
chk("tensor rank",          lambda: TensorType(T_FLOAT, (Dim(value=224), Dim(value=224))).rank() == 2)
chk("tensor str",           lambda: "Tensor<float," in str(TensorType(T_FLOAT, (Dim(value=3), Dim(value=224)))))

chk("schema field lookup",  lambda: SchemaType("S", (FieldDef("x", T_INT, False),)).get_field("x").type_ == T_INT)
chk("schema missing field", lambda: SchemaType("S", ()).get_field("x") is None)
chk("schema required",      lambda: len(SchemaType("S", (FieldDef("x", T_INT, False), FieldDef("y", T_STR, True))).required_fields()) == 1)
chk("schema free vars",     lambda: SchemaType("S", (FieldDef("x", TypeVar("'a"), False),)).free_vars() == frozenset({"'a"}))

# ════════════════════════════════════════════════════════
print("\n-- Substitution --")
# ════════════════════════════════════════════════════════

chk("empty identity",        lambda: TypeVar("'a").apply(Substitution.EMPTY) == TypeVar("'a"))
chk("bound lookup",          lambda: TypeVar("'a").apply(Substitution({"'a": T_INT})) == T_INT)
chk("unbound lookup",        lambda: TypeVar("'b").apply(Substitution({"'a": T_INT})) == TypeVar("'b"))
chk("applies to array",      lambda: ArrayType(TypeVar("'a")).apply(Substitution({"'a": T_STR})) == ArrayType(T_STR))
chk("applies to fn",         lambda: (
    FunctionType((TypeVar("'a"),), TypeVar("'b"))
    .apply(Substitution({"'a": T_INT, "'b": T_FLOAT}))
    == FunctionType((T_INT,), T_FLOAT)
))
chk("chain resolution",      lambda: (
    TypeVar("'a").apply(Substitution({"'a": TypeVar("'b"), "'b": T_INT})) == T_INT
))

def _test_compose():
    s1 = Substitution({"'a": T_INT})
    s2 = Substitution({"'b": TypeVar("'a")})
    return TypeVar("'b").apply(s1.compose(s2)) == T_INT
chk("compose",               _test_compose)

def _test_extend_no_mutate():
    s  = Substitution({"'a": T_INT})
    _  = s.extend("'b", T_STR)
    return "'b" not in s._map
chk("extend no mutate",      _test_extend_no_mutate)

chk("scheme mono no vars",   lambda: Scheme.mono(T_INT).vars == frozenset())
chk("scheme mono instantiate",lambda: Scheme.mono(T_INT).instantiate() == T_INT)

def _test_poly_inst():
    s    = Scheme(frozenset({"'a"}), TypeVar("'a"))
    inst = s.instantiate()
    return isinstance(inst, TypeVar) and inst.name != "'a"
chk("scheme poly instantiate", _test_poly_inst)

# ════════════════════════════════════════════════════════
print("\n-- Unification --")
# ════════════════════════════════════════════════════════

chk("int == int",            lambda: uni(T_INT, T_INT) == Substitution.EMPTY)
chk("str == str",            lambda: uni(T_STR, T_STR) == Substitution.EMPTY)
chk("int != str FAIL",       lambda: uni_fail(T_INT, T_STR))
chk("var -> int",            lambda: uni(TypeVar("'a"), T_INT)._map.get("'a") == T_INT)
chk("int -> var",            lambda: uni(T_INT, TypeVar("'a"))._map.get("'a") == T_INT)

def _test_var_var():
    s = uni(TypeVar("'a"), TypeVar("'b"))
    return "'a" in s._map or "'b" in s._map
chk("var -> var",            _test_var_var)

chk("arr[int] == arr[int]",  lambda: uni(ArrayType(T_INT), ArrayType(T_INT)) is not None)
chk("arr type mismatch",     lambda: uni_fail(ArrayType(T_INT), ArrayType(T_STR)))
chk("result same",           lambda: uni(ResultType(T_INT), ResultType(T_INT)) is not None)
chk("result mismatch",       lambda: uni_fail(ResultType(T_INT), ResultType(T_STR)))
chk("fn same",               lambda: uni(FunctionType((T_INT,), T_STR), FunctionType((T_INT,), T_STR)) is not None)
chk("fn arity FAIL",         lambda: uni_fail(FunctionType((T_INT,), T_STR), FunctionType((T_INT, T_STR), T_STR)))
chk("tuple same",            lambda: uni(TupleType((T_INT, T_STR)), TupleType((T_INT, T_STR))) is not None)
chk("tuple mismatch",        lambda: uni_fail(TupleType((T_INT, T_STR)), TupleType((T_STR, T_INT))))
chk("map same",              lambda: uni(MapType(T_STR, T_INT), MapType(T_STR, T_INT)) is not None)
chk("map key mismatch",      lambda: uni_fail(MapType(T_INT, T_STR), MapType(T_STR, T_STR)))

# Optional coercion
chk("nil unifies T?",        lambda: uni(T_NIL, OptionalType(T_INT)) is not None)
chk("T? unifies nil",        lambda: uni(OptionalType(T_INT), T_NIL) is not None)
chk("T unifies T?",          lambda: uni(T_INT, OptionalType(T_INT)) is not None)
chk("T? == T?",              lambda: uni(OptionalType(T_STR), OptionalType(T_STR)) is not None)
chk("T? != S? FAIL",         lambda: uni_fail(OptionalType(T_INT), OptionalType(T_STR)))

# Occurs check
chk("occurs check",          lambda: uni_fail(TypeVar("'a"), ArrayType(TypeVar("'a"))))

# Tensor shape
chk("tensor same shape",     lambda: uni(
    TensorType(T_FLOAT, (Dim(value=224), Dim(value=224))),
    TensorType(T_FLOAT, (Dim(value=224), Dim(value=224))),
) is not None)
chk("tensor shape mismatch", lambda: uni_fail(
    TensorType(T_FLOAT, (Dim(value=224), Dim(value=224))),
    TensorType(T_FLOAT, (Dim(value=224), Dim(value=128))),
))
chk("tensor rank mismatch",  lambda: uni_fail(
    TensorType(T_FLOAT, (Dim(value=224),)),
    TensorType(T_FLOAT, (Dim(value=224), Dim(value=224))),
))
chk("tensor elem mismatch",  lambda: uni_fail(
    TensorType(T_INT,   (Dim(value=224),)),
    TensorType(T_FLOAT, (Dim(value=224),)),
))
chk("tensor symbolic unifies",lambda: uni(
    TensorType(T_FLOAT, (Dim(var="d0"), Dim(value=224))),
    TensorType(T_FLOAT, (Dim(value=128), Dim(value=224))),
) is not None)

# Schema
def _test_same_schema():
    S = SchemaType("S", (FieldDef("x", T_INT, False),))
    return uni(S, S) is not None
chk("same schema unifies",   _test_same_schema)

def _test_schema_compat():
    A = SchemaType("A", (FieldDef("x", T_INT, False),))
    B = SchemaType("B", (FieldDef("x", T_INT, False), FieldDef("y", T_STR, False)))
    return uni(A, B) is not None
chk("schema structural compat", _test_schema_compat)

# ════════════════════════════════════════════════════════
print("\n-- Type Environment --")
# ════════════════════════════════════════════════════════

chk("empty not contains",    lambda: not TypeEnv.empty().contains("x"))
chk("extend contains",       lambda: TypeEnv.empty().extend_mono("x", T_INT).contains("x"))
chk("lookup found",          lambda: TypeEnv.empty().extend_mono("x", T_INT).lookup("x", SPAN).type == T_INT)

def _test_child_inherits():
    parent = TypeEnv.empty().extend_mono("x", T_INT)
    return parent.child().contains("x")
chk("child inherits",        _test_child_inherits)

def _test_child_shadows():
    parent = TypeEnv.empty().extend_mono("x", T_INT)
    child  = parent.extend_mono("x", T_STR)
    return child.lookup("x", SPAN).type == T_STR
chk("child shadows parent",  _test_child_shadows)

def _test_generalise():
    env    = TypeEnv.empty()
    tv     = TypeVar("'a0")
    scheme = env.generalize(FunctionType((tv,), tv))
    return "'a0" in scheme.vars
chk("generalise free var",   _test_generalise)

def _test_no_gen_bound():
    env    = TypeEnv.empty().extend_mono("bound", TypeVar("'a0"))
    tv     = TypeVar("'a0")
    scheme = env.generalize(FunctionType((tv,), tv))
    return "'a0" not in scheme.vars
chk("no gen for bound var",  _test_no_gen_bound)

def _test_schema_reg():
    reg = SchemaRegistry()
    S   = SchemaType("S", (FieldDef("x", T_INT, False),))
    reg.register(S)
    return reg.lookup("S", SPAN) == S
chk("schema registry",       _test_schema_reg)
chk("schema registry miss",  lambda: not SchemaRegistry().contains("X"))

# ════════════════════════════════════════════════════════
print("\n-- Inference: Literals --")
# ════════════════════════════════════════════════════════

chk("int literal",   lambda: xty("42")      == T_INT)
chk("float literal", lambda: xty("3.14")    == T_FLOAT)
chk("str literal",   lambda: xty('"hello"') == T_STR)
chk("bool true",     lambda: xty("true")    == T_BOOL)
chk("bool false",    lambda: xty("false")   == T_BOOL)
chk("nil",           lambda: xty("nil")     == T_NIL)

# ════════════════════════════════════════════════════════
print("\n-- Inference: Arithmetic --")
# ════════════════════════════════════════════════════════

chk("int+int=int",   lambda: xty("1 + 2")      == T_INT)
chk("f+f=float",     lambda: xty("1.0 + 2.0")  == T_FLOAT)
chk("i+f=float",     lambda: xty("1 + 2.0")    == T_FLOAT)
chk("str concat",    lambda: xty('"a"+"b"')     == T_STR)
chk("int*int=int",   lambda: xty("3 * 4")       == T_INT)
chk("cmp = bool",    lambda: xty("1 < 2")       == T_BOOL)
chk("eq = bool",     lambda: xty("1 == 1")      == T_BOOL)
chk("and = bool",    lambda: xty("true and false") == T_BOOL)
chk("or = bool",     lambda: xty("true or false")  == T_BOOL)
chk("not = bool",    lambda: xty("not true")    == T_BOOL)

# ════════════════════════════════════════════════════════
print("\n-- Inference: Let --")
# ════════════════════════════════════════════════════════

chk("let int",          lambda: ok("let x = 42").ok)
chk("let str",          lambda: ok('let s = "hi"').ok)
chk("let ann ok",       lambda: ok("let x: int = 42").ok)
chk("let ann mismatch", lambda: bad("let x: str = 42") is not None)
chk("let chain",        lambda: ok("let x = 1\nlet y = x + 1").ok)

# ════════════════════════════════════════════════════════
print("\n-- Inference: Functions --")
# ════════════════════════════════════════════════════════

chk("identity fn",        lambda: ok("fn id(x: int) -> int { x }").ok)
chk("fn ret mismatch",    lambda: bad("fn f() -> int { true }") is not None)
chk("fn call ok",         lambda: ok("fn double(x: int) -> int { x * 2 }\nlet r = double(5)").ok)
chk("async fn ok",        lambda: ok("async fn fetch(url: str) -> str { url }").ok)
chk("recursive fn",       lambda: ok("fn fact(n: int) -> int { if n == 0 { 1 } else { n * fact(n - 1) } }").ok)

# ════════════════════════════════════════════════════════
print("\n-- Inference: Arrays --")
# ════════════════════════════════════════════════════════

chk("empty array",        lambda: ok("let a = []").ok)
chk("int array",          lambda: ok("let a = [1, 2, 3]").ok)
chk("str array",          lambda: ok('let a = ["x", "y"]').ok)
chk("mixed array error",  lambda: bad('let a = [1, "two"]') is not None)
chk("array index",        lambda: ok("let a = [1,2,3]\nlet x = a[0]").ok)

# ════════════════════════════════════════════════════════
print("\n-- Inference: Optional/Nullable --")
# ════════════════════════════════════════════════════════

chk("nil binding",        lambda: ok("let x = nil").ok)
chk("optional schema fld",lambda: ok("schema S { x: str, y: str? }").ok)
chk("fn returns optional",lambda: ok("fn f() -> int? { nil }").ok)
chk("nullable coercion",  lambda: ok("fn f(x: int?) -> int? { nil }").ok)

# ════════════════════════════════════════════════════════
print("\n-- Inference: Result<T> and ? --")
# ════════════════════════════════════════════════════════

chk("Ok constructor",     lambda: ok("let r = Ok(42)").ok)
chk("Err constructor",    lambda: ok('let r = Err("oops")').ok)
chk("propagate on result",lambda: ok("fn f() -> Result<nil> {\n  let r = Ok(42)?\n  Ok(nil)\n}").ok)
chk("propagate non-result",lambda: bad("fn f() -> int { let x = 42?\n x }") is not None)

# ════════════════════════════════════════════════════════
print("\n-- Inference: If Expressions --")
# ════════════════════════════════════════════════════════

chk("if bool cond",       lambda: ok("let r = if true { 1 } else { 2 }").ok)
chk("if non-bool error",  lambda: bad("let r = if 42 { 1 } else { 2 }") is not None)
chk("if branches ok",     lambda: ok("let r = if true { 1 } else { 0 }").ok)
chk("if no else",         lambda: ok("let r = if true { 1 }").ok)

# ════════════════════════════════════════════════════════
print("\n-- Inference: For Loops --")
# ════════════════════════════════════════════════════════

chk("for over array",     lambda: ok("let xs = [1,2,3]\nfor x in xs { print(str(x)) }").ok)
chk("for non-array err",  lambda: bad("for x in 42 { print(str(x)) }") is not None)

# ════════════════════════════════════════════════════════
print("\n-- Inference: Match --")
# ════════════════════════════════════════════════════════

chk("match wildcard",     lambda: ok('let r = match 42 { 1 => "one", _ => "other" }').ok)
chk("match returns type", lambda: ok('match "ok" { "ok" => 1, _ => 0 }').ok)

# ════════════════════════════════════════════════════════
print("\n-- Inference: Schemas --")
# ════════════════════════════════════════════════════════

chk("schema decl ok",     lambda: ok("schema Point { x: float, y: float }").ok)
chk("schema optional fld",lambda: ok("schema User { name: str, email: str? }").ok)
chk("schema field access",lambda: ok("schema P { x: float, y: float }\nfn get_x(p: P) -> float { p.x }").ok)
chk("schema bad field",   lambda: bad("schema P { x: float }\nfn f(p: P) -> int { p.z }") is not None)
chk("schema array field", lambda: ok("schema Tags { items: str[] }").ok)
chk("schema nested",      lambda: ok("schema Inner { n: int }\nschema Outer { inner: Inner, tag: str }").ok)

# ════════════════════════════════════════════════════════
print("\n-- Inference: Pipelines --")
# ════════════════════════════════════════════════════════

GOOD_PIPE = """
fn step_a(x: int) -> str { str(x) }
fn step_b(s: str) -> bool { s == "1" }
pipeline p {
  source: int
  steps: [step_a -> step_b]
  output: bool
}
"""
chk("valid pipeline",     lambda: ok(GOOD_PIPE).ok)

BAD_PIPE = """
fn step_a(x: int) -> int { x }
fn step_b(s: str) -> bool { s == "x" }
pipeline bad {
  source: int
  steps: [step_a -> step_b]
  output: bool
}
"""
chk("step mismatch error",lambda: bad(BAD_PIPE) is not None)

OUT_MISMATCH = """
fn f(x: int) -> str { str(x) }
pipeline p { source: int  steps: [f]  output: int }
"""
chk("output mismatch err",lambda: bad(OUT_MISMATCH) is not None)

# ════════════════════════════════════════════════════════
print("\n-- Inference: Tensors --")
# ════════════════════════════════════════════════════════

chk("tensor param type",  lambda: ok("fn f(t: Tensor<float, [3, 224, 224]>) -> int { 0 }").ok)
chk("tensor return type", lambda: ok("fn f(t: Tensor<float, [768]>) -> Tensor<float, [768]> { t }").ok)

# ════════════════════════════════════════════════════════
print("\n-- Schema Validator --")
# ════════════════════════════════════════════════════════

def _make_schema(*fields):
    return SchemaType("S", tuple(FieldDef(n, t, o) for n, t, o in fields))

chk("valid dict",          lambda: SchemaValidator.is_valid({"x": 42, "y": "hi"}, _make_schema(("x", T_INT, False), ("y", T_STR, False))))
chk("missing required",    lambda: not SchemaValidator.is_valid({}, _make_schema(("x", T_INT, False))))
chk("wrong type",          lambda: not SchemaValidator.is_valid({"x": "oops"}, _make_schema(("x", T_INT, False))))
chk("optional absent",     lambda: SchemaValidator.is_valid({"x": 1}, _make_schema(("x", T_INT, False), ("y", T_STR, True))))
chk("optional present",    lambda: SchemaValidator.is_valid({"y": "hello"}, _make_schema(("y", T_STR, True))))
chk("optional wrong type", lambda: not SchemaValidator.is_valid({"y": 42}, _make_schema(("y", T_STR, True))))
chk("nested array ok",     lambda: SchemaValidator.is_valid({"tags": ["a","b"]}, _make_schema(("tags", ArrayType(T_STR), False))))
chk("nested array bad",    lambda: not SchemaValidator.is_valid({"tags": [1, 2]}, _make_schema(("tags", ArrayType(T_STR), False))))

# ════════════════════════════════════════════════════════
print("\n-- Full Program --")
# ════════════════════════════════════════════════════════

FULL = """
schema ImageInput {
  path:   str,
  label:  str?,
  width:  int,
  height: int
}
schema ClassResult { label: str, confidence: float }

fn preprocess(img: ImageInput) -> Tensor<float, [3, 224, 224]> {
  load_image(img.path)
}
fn score(t: Tensor<float, [3, 224, 224]>) -> str {
  "cat"
}
pipeline classify {
  source: ImageInput[]
  steps:  [preprocess -> score]
  output: str[]
}
fn compute(x: int, y: int) -> float {
  let s = x + y
  float(s)
}
fn greet(name: str) -> str {
  "Hello " + name
}
fn load_safe(path: str) -> Result<nil> {
  if not file_exists(path) { return Err("not found") }
  Ok(nil)
}
"""

chk("full program ok",    lambda: ok(FULL).ok)
chk("schemas registered", lambda: ok(FULL).schemas.contains("ImageInput"))
chk("has fn bindings",    lambda: any(isinstance(t, FunctionType) for _, t in ok(FULL).bindings()))
chk("has many bindings",  lambda: len(list(ok(FULL).bindings())) >= 5)

# ════════════════════════════════════════════════════════
print("\n-- Error Recovery --")
# ════════════════════════════════════════════════════════

chk("type error reported",    lambda: len(bad("let x: str = 42").errors) >= 1)
chk("multiple errors",        lambda: len(bad("let a: str = 42\nlet b: int = true").errors) >= 2)
chk("error + valid coexist",  lambda: not TypeChecker.check("let a: str = 42\nlet b = 99", "<t>").ok)

# ════════════════════════════════════════════════════════
print("\n-- API Surface --")
# ════════════════════════════════════════════════════════

chk("version 0.2.0",      lambda: varek.__version__ == "0.2.0")
chk("author",             lambda: "Kenneth" in varek.__author__)
chk("check() ok",         lambda: varek.check("let x = 1").ok)
chk("check() fail",       lambda: not varek.check("let x: str = 1").ok)
chk("check_expr int",     lambda: varek.check_expr("42")[0] == T_INT)
chk("check_expr float",   lambda: varek.check_expr("3.14")[0] == T_FLOAT)
chk("check_expr str",     lambda: varek.check_expr('"hi"')[0] == T_STR)
chk("CheckResult ok",     lambda: isinstance(varek.check("let x = 1"), varek.CheckResult))
chk("report pass",        lambda: "✓" in varek.check("let x = 1").report())
chk("pretty_bindings",    lambda: len(varek.check("let x = 1").pretty_bindings()) > 0)

# ════════════════════════════════════════════════════════
print(f"\n{'='*50}")
print(f"  {P} passed  |  {F} failed  |  {P+F} total")
print(f"{'='*50}")
if FAILS:
    print("\nFailed:")
    for n, m in FAILS: print(f"  {n}: {m}")
import sys; sys.exit(0 if F == 0 else 1)
