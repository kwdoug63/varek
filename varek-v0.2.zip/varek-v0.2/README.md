# VAREK — v0.2
### AI Pipeline Programming Language

> *One language. Every stage of the AI pipeline.*

[![License: MIT](https://img.shields.io/badge/License-MIT-00ffe0.svg)](LICENSE)
[![Version](https://img.shields.io/badge/version-0.2.0-7c3aed.svg)]()
[![Tests](https://img.shields.io/badge/tests-163%20passed-22c55e.svg)]()

---

## What's new in v0.2 — Type System + Inference Engine

| Component | File | Description |
|-----------|------|-------------|
| **Type Algebra** | `varek/types.py` | Full type hierarchy: primitives, TypeVar, Optional, Array, Map, Tuple, Tensor, Result, Function, Schema, Scheme |
| **Unification** | `varek/unify.py` | Robinson's unification + occurs check + tensor shape unification + optional coercion |
| **Type Environment** | `varek/env.py` | Lexically-scoped symbol tables + let-generalisation + "did you mean?" hints |
| **Built-ins** | `varek/builtins.py` | Typed signatures for all built-in functions and methods |
| **Inference Engine** | `varek/infer.py` | Algorithm W — Hindley-Milner inference for the full AST |
| **Type Checker** | `varek/checker.py` | Public API + schema validator |
| **Tests** | `tests/test_types.py` | 163-test suite (100% pass) |

---

## Quick Start

```bash
git clone https://github.com/varek-lang/varek
cd varek
python varek.py demo
```

**Requirements:** Python 3.10+, no dependencies.

---

## Type System at a Glance

```python
import varek

# Check a full program
result = varek.check(source, "main.syn")
if result.ok:
    for name, ty in result.bindings():
        print(f"{name} : {ty}")
else:
    print(result.report())

# Infer a single expression
ty, errors = varek.check_expr("1 + 2.0")
print(ty)   # float

# Validate data against a schema at runtime
from varek import SchemaType, FieldDef, T_STR, T_INT, SchemaValidator
schema = SchemaType("User", (
    FieldDef("name", T_STR, False),
    FieldDef("age",  T_INT, True),
))
valid = SchemaValidator.is_valid({"name": "Alice"}, schema)  # True
```

---

## What the Type System Covers

**Hindley-Milner inference (Algorithm W)**
- Infers types without annotations in most positions
- Let-polymorphism: `fn id(x: int) -> int` generalises correctly
- Composes substitutions across the entire program

**Nullable/Optional types**
- `T?` is a first-class type — not a nullable pointer
- `nil` unifies with any `T?`
- `T` implicitly coerces to `T?` at assignment
- Optional fields in schemas are tracked separately from optional types

**Tensor shape tracking**
- `Tensor<float, [3, 224, 224]>` — concrete shape
- `Tensor<float, [d0, d1]>` — symbolic shape during inference
- Shape unification: dimension variables resolve to concrete values
- Rank mismatches caught at compile time

**Schema validation**
- `schema` declarations create structural types
- Field access is type-checked against the schema
- Structural compatibility: `B` is assignable to `A` if `B` has all of `A`'s required fields
- Runtime validator: `SchemaValidator.is_valid(data, schema)`

**Pipeline type verification**
- Each step function's input type must match the previous step's output
- Source array element type threads through steps
- Output element type is verified against declaration

**Result<T> and ? propagation**
- `Ok(x)` : `∀ 'a. ('a) -> Result<'a>`
- `Err(msg)` : `∀ 'a. (str) -> Result<'a>`
- `expr?` unwraps `Result<T>` to `T`, propagating errors

---

## Roadmap

- [x] **v0.1** — Formal grammar, lexer, parser
- [x] **v0.2** — Type system + HM inference ← *you are here*
- [ ] **v0.3** — LLVM compilation backend
- [ ] **v0.4** — Standard library
- [ ] **v0.5** — Package manager CLI
- [ ] **v1.0** — Stable release

---

## License

MIT — *Kenneth Wayne Douglas, MD*
