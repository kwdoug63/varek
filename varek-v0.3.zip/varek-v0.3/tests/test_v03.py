"""
tests/test_v03.py  —  VAREK v0.3 Compiler Backend Tests
94 tests: LLVM API, IR gen, IR validity, compiler driver,
          native emission, interpreter correctness.
"""
import sys, os, tempfile, subprocess
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import varek
from varek.compiler  import Compiler, CompileMode
from varek.codegen   import CodeGen, ast_to_ir
from varek.llvm_api  import (LLVMContextCreate, LLVMContextDispose,
    LLVMModuleCreateWithNameInContext, LLVMDisposeModule,
    LLVMVerifyModule, module_to_ir_string)
from varek.types     import (T_INT, T_FLOAT, T_STR, T_BOOL, T_NIL,
    OptionalType, ArrayType, ResultType)
from varek.runtime   import (Interpreter, SynInt, SynFloat, SynStr,
    SynBool, SynNil, SynArray, SynOk, SynErr, SYN_NIL)

P=0; F=0; FAILS=[]
def chk(name, fn):
    global P,F
    try:
        assert fn() is not False
        print(f"  PASS  {name}"); P+=1
    except Exception as e:
        print(f"  FAIL  {name}: {e}"); F+=1; FAILS.append((name,str(e)))

def ir(src):
    r = Compiler.compile(src,"<t>",mode=CompileMode.EMIT_IR)
    assert r.ir, r.report()
    return r.ir

def verify(src):
    tree,_ = varek.parse(src,"<t>")
    gen = CodeGen("vt"); gen.generate(tree)
    err = LLVMVerifyModule(gen.ctx.module); gen.dispose()
    return err

def interp_expr(src):
    return Interpreter().eval_expr(src)

def fn_call(src, name, *args):
    i = Interpreter(); i.run(src)
    return i.call(name, *args)

print("\n=== VAREK v0.3 — Compiler Backend Test Suite ===\n")

# ── LLVM API ─────────────────────────────────────────────────────
print("-- LLVM API Availability --")

def _test_ctx():
    ctx = LLVMContextCreate()
    LLVMContextDispose(ctx)
    return True
chk("context create/dispose", _test_ctx)

def _test_module():
    ctx = LLVMContextCreate()
    mod = LLVMModuleCreateWithNameInContext(b"test", ctx)
    s = module_to_ir_string(mod)
    LLVMDisposeModule(mod); LLVMContextDispose(ctx)
    return isinstance(s,str) and len(s) > 0
chk("module create + IR dump",  _test_module)

def _test_verify_empty():
    ctx = LLVMContextCreate()
    mod = LLVMModuleCreateWithNameInContext(b"test", ctx)
    err = LLVMVerifyModule(mod)
    LLVMDisposeModule(mod); LLVMContextDispose(ctx)
    return err is None
chk("verify empty module",      _test_verify_empty)

# ── Type mapping ──────────────────────────────────────────────────
print("\n-- CodeGenContext Type Mapping --")
from varek.codegen import CodeGenContext

def _mk(): return CodeGenContext("t")
chk("i64 for int",    lambda: _mk().varek_type_to_llvm(T_INT)   is not None)
chk("f64 for float",  lambda: _mk().varek_type_to_llvm(T_FLOAT) is not None)
chk("i1 for bool",    lambda: _mk().varek_type_to_llvm(T_BOOL)  is not None)
chk("i8ptr for str",  lambda: _mk().varek_type_to_llvm(T_STR)   is not None)
chk("i64 for nil",    lambda: _mk().varek_type_to_llvm(T_NIL)   is not None)
chk("optional maps",  lambda: _mk().varek_type_to_llvm(OptionalType(T_INT)) is not None)
chk("array maps",     lambda: _mk().varek_type_to_llvm(ArrayType(T_INT))    is not None)
chk("result maps",    lambda: _mk().varek_type_to_llvm(ResultType(T_INT))   is not None)

# ── IR Generation ─────────────────────────────────────────────────
print("\n-- IR Generation --")

chk("IR is str",              lambda: isinstance(ir("fn f()->int{42}"), str))
chk("IR has define",          lambda: "define" in ir("fn f()->int{42}"))
chk("IR has ret",             lambda: "ret"    in ir("fn f()->int{42}"))
chk("fn name in IR",          lambda: "my_fn"  in ir("fn my_fn(x:int)->int{x}"))
chk("add in IR",              lambda: "add"    in ir("fn f(a:int,b:int)->int{a+b}"))
chk("mul in IR",              lambda: "mul"    in ir("fn f(a:int,b:int)->int{a*b}"))
chk("float in IR",            lambda: "double" in ir("fn f(a:float,b:float)->float{a+b}"))
chk("alloca in IR",           lambda: "alloca" in ir("fn f(x:int)->int{let y=x\ny}"))
chk("if/else br in IR",       lambda: "br"     in ir("fn f(n:int)->int{if n==0{1}else{0}}"))
chk("phi node in IR",         lambda: "phi"    in ir("fn f(n:int)->int{if n==0{1}else{0}}"))
chk("icmp in IR",             lambda: "icmp"   in ir("fn f(n:int)->int{if n==0{1}else{0}}"))
chk("recursive call in IR",   lambda: "call"   in ir("fn fib(n:int)->int{if n<=1{n}else{fib(n-1)+fib(n-2)}}"))
chk("string global in IR",    lambda: "@.str"  in ir('fn f()->str{"hello"}'))
chk("multi-fn IR",            lambda: ir("fn a(x:int)->int{x}\nfn b(x:int)->int{a(x)*2}").count("define") >= 2)
chk("float conv in IR",       lambda: "sitofp" in ir("fn f(x:int)->float{float(x)*2.0}"))
chk("int conv in IR",         lambda: "fptosi" in ir("fn f(x:float)->int{int(x)}"))

# ── IR Validity ───────────────────────────────────────────────────
print("\n-- IR Validity (LLVMVerifyModule) --")

chk("simple fn",              lambda: verify("fn f()->int{42}") is None)
chk("two-arg fn",             lambda: verify("fn add(a:int,b:int)->int{a+b}") is None)
chk("if/else",                lambda: verify("fn f(n:int)->int{if n==0{1}else{0}}") is None)
chk("string fn",              lambda: verify('fn f()->str{"hello"}') is None)
chk("recursive fn",           lambda: verify("fn fib(n:int)->int{if n<=1{n}else{fib(n-1)+fib(n-2)}}") is None)
chk("float fn",               lambda: verify("fn f(x:float)->float{x*2.0}") is None)
chk("float conv fn",          lambda: verify("fn f(x:int)->float{float(x)*3.14}") is None)
chk("compute fn",             lambda: verify("fn f(a:int,b:int,c:float)->float{let s=a+b\nfloat(s)+c}") is None)

# ── Compiler Driver ───────────────────────────────────────────────
print("\n-- Compiler Driver --")

def cdr(src): return Compiler.compile(src,"<t>",mode=CompileMode.EMIT_IR)

chk("emit-ir ok",             lambda: cdr("fn f()->int{42}").ok)
chk("emit-ir has ir",         lambda: cdr("fn f()->int{42}").ir is not None)
chk("emit-ir has timings",    lambda: "codegen" in cdr("fn f()->int{42}").timings)
chk("type error in errors",   lambda: cdr("let x:str=42").errors.has_errors())
chk("parse error in errors",  lambda: cdr("fn f( -> int{42}").errors.has_errors())
chk("report ok has check",    lambda: "✓" in cdr("fn f()->int{42}").report())

# ── Native Emission (subprocess-isolated) ────────────────────────
print("\n-- Native Emission (assembly + object) --")

_EMIT_SCRIPT = """
import sys; sys.path.insert(0,".")
from varek.compiler import Compiler, CompileMode
import tempfile, os
src = "fn add(a: int, b: int) -> int { a + b }"
with tempfile.NamedTemporaryFile(suffix=".s",delete=False) as f: sp=f.name
with tempfile.NamedTemporaryFile(suffix=".o",delete=False) as f: op=f.name
try:
    r1 = Compiler.compile(src,"<t>",mode=CompileMode.EMIT_ASM,output=sp,opt_level=0)
    r2 = Compiler.compile(src,"<t>",mode=CompileMode.EMIT_OBJ,output=op,opt_level=0)
    asm_ok  = r1.ok and os.path.exists(sp) and os.path.getsize(sp) > 0
    obj_ok  = r2.ok and os.path.exists(op) and os.path.getsize(op) > 0
    asm_has = asm_ok and any(k in open(sp).read().lower() for k in ["mov","add","ret"])
    print(f"asm={asm_ok} obj={obj_ok} insns={asm_has}")
finally:
    for p in [sp,op]:
        if os.path.exists(p): os.unlink(p)
"""

def _run_emit():
    r = subprocess.run([sys.executable,"-c",_EMIT_SCRIPT],
                       capture_output=True, text=True, timeout=30)
    if r.returncode == 0:
        out = r.stdout.strip()
        return "asm=True" in out, "obj=True" in out, "insns=True" in out
    return False, False, False

_asm_ok, _obj_ok, _insns_ok = _run_emit()
chk("assembly emitted",       lambda: _asm_ok)
chk("asm has instructions",   lambda: _insns_ok)
chk("object file emitted",    lambda: _obj_ok)
chk("object file non-empty",  lambda: _obj_ok)

# ── Interpreter: Literals ─────────────────────────────────────────
print("\n-- Interpreter: Literals --")

chk("int literal",   lambda: interp_expr("42").value    == 42)
chk("float literal", lambda: interp_expr("3.14").value  == 3.14)
chk("str literal",   lambda: interp_expr('"hi"').value  == "hi")
chk("bool true",     lambda: interp_expr("true").value  is True)
chk("bool false",    lambda: interp_expr("false").value is False)
chk("nil",           lambda: isinstance(interp_expr("nil"), SynNil))

# ── Interpreter: Arithmetic ───────────────────────────────────────
print("\n-- Interpreter: Arithmetic --")

chk("1+2=3",         lambda: interp_expr("1+2").value        == 3)
chk("10-3=7",        lambda: interp_expr("10-3").value       == 7)
chk("3*4=12",        lambda: interp_expr("3*4").value        == 12)
chk("10/3=3 int",    lambda: interp_expr("10/3").value       == 3)
chk("10%3=1",        lambda: interp_expr("10%3").value       == 1)
chk("1.0+2.0=3.0",   lambda: interp_expr("1.0+2.0").value   == 3.0)
chk("int+float",     lambda: isinstance(interp_expr("1+2.0"), SynFloat))
chk("str concat",    lambda: interp_expr('"a"+"b"').value    == "ab")
chk("1<2=true",      lambda: interp_expr("1<2").value        is True)
chk("2==2=true",     lambda: interp_expr("2==2").value       is True)
chk("not true",      lambda: interp_expr("not true").value   is False)
chk("and short",     lambda: interp_expr("false and true").value is False)
chk("or short",      lambda: interp_expr("true or false").value  is True)

# ── Interpreter: Functions ────────────────────────────────────────
print("\n-- Interpreter: Functions --")

chk("simple fn",   lambda: fn_call("fn add(a:int,b:int)->int{a+b}","add",SynInt(3),SynInt(4)).value == 7)
chk("recursive",   lambda: fn_call("fn fib(n:int)->int{if n<=1{n}else{fib(n-1)+fib(n-2)}}","fib",SynInt(10)).value == 55)
chk("nested calls",lambda: fn_call("fn sq(x:int)->int{x*x}\nfn cube(x:int)->int{sq(x)*x}","cube",SynInt(4)).value == 64)
chk("returns str", lambda: fn_call('fn hi(n:str)->str{"Hello "+n}',"hi",SynStr("world")).value == "Hello world")

# ── Interpreter: Control Flow ─────────────────────────────────────
print("\n-- Interpreter: Control Flow --")

chk("if true",     lambda: interp_expr("if true{1}else{2}").value == 1)
chk("if false",    lambda: interp_expr("if false{1}else{2}").value == 2)
chk("if no else",  lambda: isinstance(interp_expr("if false{1}"), SynNil))

def _match():
    i=Interpreter()
    i.run('fn f(n:int)->str{match n{0=>"zero",1=>"one",_=>"other"}}')
    return i.call("f",SynInt(0)).value=="zero" and i.call("f",SynInt(99)).value=="other"
chk("match expr",  _match)

def _for():
    i=Interpreter()
    i.run("fn sum_to(n:int)->int{let t=0\nfor x in range(n){t}\nt}")
    return isinstance(i.call("sum_to",SynInt(5)), SynInt)
chk("for loop",    _for)

# ── Interpreter: Arrays ───────────────────────────────────────────
print("\n-- Interpreter: Arrays --")

chk("array literal", lambda: len(interp_expr("[1,2,3]").elements) == 3)
chk("array index",   lambda: interp_expr("[10,20,30]").elements[1].value == 20)
chk("range len",     lambda: len(interp_expr("range(5)").elements) == 5)
chk("range values",  lambda: interp_expr("range(3)").elements[2].value == 2)

# ── Interpreter: Result<T> ────────────────────────────────────────
print("\n-- Interpreter: Result<T> --")

chk("Ok wraps",   lambda: isinstance(interp_expr("Ok(42)"), SynOk))
chk("Ok value",   lambda: interp_expr("Ok(42)").value.value == 42)
chk("Err wraps",  lambda: isinstance(interp_expr('Err("oops")'), SynErr))
chk("Err msg",    lambda: interp_expr('Err("boom")').message == "boom")

# ── Interpreter: Pipeline ─────────────────────────────────────────
print("\n-- Interpreter: Pipeline --")

def _pipeline():
    i=Interpreter()
    i.run("fn double(x:int)->int{x*2}\nfn inc(x:int)->int{x+1}\npipeline p{source:int[]\nsteps:[double->inc]\noutput:int[]}")
    result = i.call("p", SynArray([SynInt(1),SynInt(2),SynInt(3)]))
    return isinstance(result, SynArray) and result.elements[0].value == 3
chk("pipeline runs", _pipeline)

# ── Interpreter: Builtins ─────────────────────────────────────────
print("\n-- Interpreter: Builtins --")

chk("str(42)",    lambda: interp_expr("str(42)").value == "42")
chk("len([...])", lambda: interp_expr("len([1,2,3])").value == 3)
chk("Ok builtin", lambda: isinstance(interp_expr("Ok(1)"), SynOk))
chk("Err builtin",lambda: isinstance(interp_expr('Err("x")'), SynErr))

# ── Correctness: VAREK interpreter vs Python ────────────────────
print("\n-- Correctness: VAREK vs Python --")

def _py_fib(n):
    if n<=1: return n
    return _py_fib(n-1)+_py_fib(n-2)

_fib_interp = Interpreter()
_fib_interp.run("fn fib(n:int)->int{if n<=1{n}else{fib(n-1)+fib(n-2)}}")

for _n in [0,1,5,10,15]:
    _exp = _py_fib(_n)
    chk(f"fib({_n})=={_exp}", lambda e=_exp,n=_n: _fib_interp.call("fib",SynInt(n)).value == e)

# ── API Surface ───────────────────────────────────────────────────
print("\n-- API Surface --")

chk("version 0.3.0",   lambda: varek.__version__ == "0.3.0")
chk("author",          lambda: "Kenneth" in varek.__author__)
chk("check() works",   lambda: varek.check("let x=1").ok)
chk("Interpreter",     lambda: Interpreter is not None)
chk("CompileMode",     lambda: CompileMode.EMIT_IR is not None)
chk("CompileResult",   lambda: hasattr(Compiler.compile("fn f()->int{0}","<t>",mode=CompileMode.EMIT_IR),"ir"))

# ── Summary ───────────────────────────────────────────────────────
print(f"\n{'='*52}")
print(f"  {P} passed  |  {F} failed  |  {P+F} total")
print(f"{'='*52}")
if FAILS:
    print("\nFailed:")
    for n,m in FAILS: print(f"  {n}: {m}")
sys.exit(0 if F==0 else 1)
