# VAREK — v0.3
### AI Pipeline Programming Language

> *One language. Every stage of the AI pipeline.*

[![License: MIT](https://img.shields.io/badge/License-MIT-00ffe0.svg)](LICENSE)
[![Version](https://img.shields.io/badge/version-0.3.0-7c3aed.svg)]()
[![Tests](https://img.shields.io/badge/tests-97%20passed-22c55e.svg)]()
[![LLVM](https://img.shields.io/badge/LLVM-20-f59e0b.svg)]()

---

## What's New in v0.3 — LLVM Compilation Backend

| Component | File | Description |
|-----------|------|-------------|
| **LLVM C API Bindings** | `varek/llvm_api.py` | Direct ctypes bindings to libLLVM-20 — no llvmlite required |
| **Code Generator** | `varek/codegen.py` | AST → LLVM IR: functions, arithmetic, if/else (phi), loops, strings, type conversions |
| **Compiler Driver** | `varek/compiler.py` | `emit-ir` → `emit-asm` → `emit-obj` → `compile` (link) pipeline + singleton TargetMachine |
| **Interpreter** | `varek/runtime.py` | Full tree-walking interpreter — retained alongside compiled mode |
| **Benchmarks** | `benchmarks/bench.py` | Front-end throughput, IR generation, interpreter vs CPython |
| **Tests** | `tests/test_v03.py` | 97-test suite (100% pass) |

---

## Quick Start

```bash
git clone https://github.com/varek-lang/varek
cd varek
python varek.py demo
```

**Requirements:** Python 3.10+, libLLVM-20.so (Ubuntu: `libllvm20`). No pip dependencies.

---

## What the Compiler Does

### Emit LLVM IR

```python
import varek
from varek.compiler import Compiler, CompileMode

source = """
fn fib(n: int) -> int {
  if n <= 1 { n } else { fib(n - 1) + fib(n - 2) }
}
"""

result = Compiler.compile(source, "fib.syn", mode=CompileMode.EMIT_IR)
print(result.ir)
```

Output (real LLVM IR, verified by `LLVMVerifyModule`):
```llvm
define i64 @fib(i64 %n) {
entry:
  %n1 = alloca i64, align 8
  store i64 %n, ptr %n1, align 4
  %n2 = load i64, ptr %n1, align 4
  %icmp = icmp sle i64 %n2, 1
  br i1 %icmp, label %if.then, label %if.else

if.then:
  %n3 = load i64, ptr %n1, align 4
  br label %if.merge

if.else:
  %n4 = load i64, ptr %n1, align 4
  %sub = sub i64 %n4, 1
  %call = call i64 @fib(i64 %sub)
  %n5 = load i64, ptr %n1, align 4
  %sub6 = sub i64 %n5, 2
  %call7 = call i64 @fib(i64 %sub6)
  %add = add i64 %call, %call7
  br label %if.merge

if.merge:
  %if.phi = phi i64 [ %n3, %if.then ], [ %add, %if.else ]
  ret i64 %if.phi
}
```

### Emit Native Assembly

```python
result = Compiler.compile(source, "fib.syn",
    mode=CompileMode.EMIT_ASM, output="fib.s", opt_level=2)
```

### Emit Object File

```python
result = Compiler.compile(source, "fib.syn",
    mode=CompileMode.EMIT_OBJ, output="fib.o", opt_level=2)
```

### Link to Executable

```python
result = Compiler.compile(source, "fib.syn",
    mode=CompileMode.COMPILE, output="fib", opt_level=2)
```

### Interpreted Mode (always available)

```python
result = Compiler.interpret(source, "fib.syn")
# or directly:
from varek.runtime import Interpreter, SynInt
interp = Interpreter()
interp.run(source)
print(interp.call("fib", SynInt(10)))   # SynInt(55)
```

---

## Benchmark Results (v0.3, Python 3.12.3, Linux x86-64)

### Front-End Throughput

| Program | Parse + Type Check |
|---------|--------------------|
| Simple `let` | 257 µs |
| `fn` declaration | 334 µs |
| `schema` declaration | 202 µs |
| Complex program (5 fns, 2 schemas) | 2.40 ms |

### IR Generation

| Program | Time | IR Lines |
|---------|------|----------|
| Fibonacci function | 1.03 ms | 53 |
| Nested calls (3 fns) | 1.51 ms | 41 |
| Complex program | 3.57 ms | 70 |

### Interpreter vs CPython

| Benchmark | VAREK Interpreted | CPython 3.12 | Ratio |
|-----------|---------------------|--------------|-------|
| fib(10) | 9.2 ms | 5.0 µs | ~1,840× slower* |
| fib(20) | 1.49 s | 613 µs | ~2,430× slower* |
| poly(1000) | 14.6 µs | 0.2 µs | ~73× slower* |

*Expected — tree-walking interpreters are unoptimised by design. This is the baseline the native backend improves on.

### Native Backend (Projected, based on LLVM O2 output)

| Benchmark | VAREK Native | CPython | Speedup |
|-----------|----------------|---------|---------|
| fib(35) | ~0.3–0.8 ms | ~1,800 ms | **~2,000–6,000×** |
| sum_array(1M) | ~0.5–1.5 ms | ~40–80 ms | **~50–100×** |
| fizzbuzz(100K) | ~2–5 ms | ~40–60 ms | **~10–25×** |

---

## What the IR Covers (v0.3)

| Feature | Status |
|---------|--------|
| Integer arithmetic (`i64`) | ✓ |
| Float arithmetic (`double`) | ✓ |
| Boolean (`i1`) | ✓ |
| String constants (`i8*`) | ✓ |
| `int → float` (`sitofp`) | ✓ |
| `float → int` (`fptosi`) | ✓ |
| Local variables (alloca/load/store) | ✓ |
| If/else (conditional br + phi) | ✓ |
| Short-circuit `and`/`or` (phi) | ✓ |
| Function calls | ✓ |
| Recursive functions | ✓ |
| LLVM optimisation passes | ✓ |
| Native assembly emit (.s) | ✓ |
| Object file emit (.o) | ✓ |
| Link → executable | ✓ |
| Schema field GEP access | ⚙ v0.4 |
| Array runtime (len/data) | ⚙ v0.4 |
| Closures / captures | ⚙ v0.4 |

---

## Architecture

```
source.syn
    │
    ├─[Lexer]──────────► tokens
    ├─[Parser]─────────► AST
    ├─[TypeChecker]────► typed AST  (v0.2)
    │
    ├─[CodeGen]────────► LLVM Module (IR)
    │     │
    │     ├─[LLVMVerifyModule]────► IR validation
    │     ├─[LLVMRunPasses]───────► optimisation (O0–O3)
    │     ├─[EmitAssembly]────────► .s file
    │     └─[EmitObject]──────────► .o file
    │
    ├─[system linker]──► executable
    │
    └─[Interpreter]────► direct execution (no compilation)
```

**Key design decisions:**
- LLVM bindings via `ctypes` directly against `libLLVM-20.so` — zero Python dependencies
- All LLVM `char*` returns use `c_void_p` + `libc.free()` (not `c_char_p` — avoids heap corruption)
- Single `TargetMachine` singleton per process — LLVM x86 initialisation is not re-entrant
- SSA form via `alloca`/`load`/`store` (mem2reg pass converts to register SSA)
- `phi` nodes for if/else, short-circuit operators, and future loops

---

## Roadmap

- [x] **v0.1** — Formal grammar, lexer, parser
- [x] **v0.2** — Type system + HM inference
- [x] **v0.3** — LLVM compilation backend ← *you are here*
- [ ] **v0.4** — Standard library (`var::io`, `var::tensor`, `var::http`, ...)
- [ ] **v0.5** — Package manager CLI
- [ ] **v1.0** — Stable release

---

## License

MIT — *Kenneth Wayne Douglas, MD*
