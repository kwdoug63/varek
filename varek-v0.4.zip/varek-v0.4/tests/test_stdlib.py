"""
tests/test_stdlib.py
─────────────────────
VAREK v0.4 Standard Library Test Suite.
Tests all 7 stdlib modules + the import resolver.
Run: python tests/test_stdlib.py
"""
import sys, os, tempfile, math, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
from varek.runtime import (
    Interpreter, SynInt, SynFloat, SynStr, SynBool, SynNil,
    SynArray, SynMap, SynOk, SynErr, SynTensor, SYN_NIL, SYN_TRUE, SYN_FALSE,
)
from varek.stdlib import resolve_import, get_module, list_modules, module_names
from varek.stdlib.tensor import _from_np, _to_np
import varek

P=0; F=0; FAILS=[]
def chk(name, fn):
    global P, F
    try:
        assert fn() is not False
        print(f"  PASS  {name}"); P+=1
    except Exception as e:
        print(f"  FAIL  {name}: {e}"); F+=1; FAILS.append((name,str(e)))

def bi(module, name):
    m = get_module(module)
    return m.get(name).impl

def call(module, name, *args):
    return bi(module, name)(list(args))

print(f"\n=== VAREK v0.4 — Standard Library Test Suite ===\n")

# ════════════════════════════════════════════════════════
print("-- Module Registry --")
# ════════════════════════════════════════════════════════

chk("list_modules returns 7",    lambda: len(list_modules()) == 7)
chk("var::io in modules",        lambda: "var::io" in list_modules())
chk("var::tensor in modules",    lambda: "var::tensor" in list_modules())
chk("get_module io works",       lambda: get_module("io") is not None)
chk("get_module tensor works",   lambda: get_module("tensor") is not None)
chk("module names non-empty",    lambda: len(module_names("io")) > 0)

def _test_resolve_module():
    b = resolve_import(["syn","io"], None)
    return "io" in b
chk("resolve var::io",           _test_resolve_module)

def _test_resolve_alias():
    b = resolve_import(["syn","tensor"], "T")
    return "T" in b
chk("resolve with alias",        _test_resolve_alias)

def _test_resolve_item():
    b = resolve_import(["syn","tensor","zeros"], None)
    return "zeros" in b
chk("resolve var::tensor::zeros",_test_resolve_item)

chk("resolve non-syn = empty",   lambda: resolve_import(["python","numpy"], None) == {})

# ════════════════════════════════════════════════════════
print("\n-- var::io --")
# ════════════════════════════════════════════════════════

with tempfile.TemporaryDirectory() as tmpdir:
    test_file = os.path.join(tmpdir, "test.txt")
    test_file2= os.path.join(tmpdir, "copy.txt")
    test_gz   = os.path.join(tmpdir, "test.gz")
    test_sub  = os.path.join(tmpdir, "sub")

    # Write
    r = call("io","write_file", SynStr(test_file), SynStr("hello VAREK"))
    chk("write_file ok",         lambda r=r: isinstance(r, SynOk))
    chk("file_exists true",      lambda: call("io","file_exists",SynStr(test_file)) == SYN_TRUE)
    chk("file_exists false",     lambda: call("io","file_exists",SynStr("/nonexistent/x.txt")) == SYN_FALSE)

    # Read
    r2 = call("io","read_file", SynStr(test_file))
    chk("read_file ok",          lambda r2=r2: isinstance(r2, SynOk))
    chk("read_file content",     lambda r2=r2: r2.value.value == "hello VAREK")

    # Read lines
    call("io","write_file", SynStr(test_file), SynStr("line1\nline2\nline3"))
    r3 = call("io","read_lines", SynStr(test_file))
    chk("read_lines ok",         lambda r3=r3: isinstance(r3, SynOk))
    chk("read_lines count",      lambda r3=r3: len(r3.value.elements) == 3)
    chk("read_lines content",    lambda r3=r3: r3.value.elements[0].value == "line1")

    # Append
    call("io","append_file", SynStr(test_file), SynStr("\nline4"))
    r4 = call("io","read_lines", SynStr(test_file))
    chk("append_file works",     lambda r4=r4: len(r4.value.elements) == 4)

    # Copy
    rc = call("io","copy_file", SynStr(test_file), SynStr(test_file2))
    chk("copy_file ok",          lambda rc=rc: isinstance(rc, SynOk))
    chk("copy file exists",      lambda: call("io","file_exists",SynStr(test_file2)) == SYN_TRUE)

    # File size
    fs = call("io","file_size", SynStr(test_file))
    chk("file_size ok",          lambda fs=fs: isinstance(fs, SynOk) and fs.value.value > 0)

    # Make dir
    md = call("io","make_dir", SynStr(test_sub))
    chk("make_dir ok",           lambda md=md: isinstance(md, SynOk))
    chk("is_dir true",           lambda: call("io","is_dir",SynStr(test_sub)) == SYN_TRUE)
    chk("is_file false for dir", lambda: call("io","is_file",SynStr(test_sub)) == SYN_FALSE)

    # List dir
    ld = call("io","list_dir", SynStr(tmpdir))
    chk("list_dir ok",           lambda ld=ld: isinstance(ld, SynOk))
    chk("list_dir non-empty",    lambda ld=ld: len(ld.value.elements) > 0)

    # Path ops
    chk("basename",              lambda: call("io","basename",SynStr(test_file)).value == "test.txt")
    chk("dirname",               lambda: call("io","dirname",SynStr(test_file)).value == tmpdir)
    chk("join_path",             lambda: call("io","join_path",SynStr(tmpdir),SynStr("x.txt")).value == os.path.join(tmpdir,"x.txt"))
    chk("stem",                  lambda: call("io","stem",SynStr("foo/bar.txt")).value == "bar")
    chk("extension",             lambda: call("io","extension",SynStr("foo/bar.txt")).value == ".txt")
    chk("with_extension",        lambda: call("io","with_extension",SynStr("foo/bar.txt"),SynStr(".syn")).value.endswith(".syn"))

    # Gzip
    wg = call("io","write_gzip", SynStr(test_gz), SynStr("compressed content"))
    chk("write_gzip ok",         lambda wg=wg: isinstance(wg, SynOk))
    rg = call("io","read_gzip",  SynStr(test_gz))
    chk("read_gzip ok",          lambda rg=rg: isinstance(rg, SynOk))
    chk("gzip roundtrip",        lambda rg=rg: rg.value.value == "compressed content")

    # Remove
    rr = call("io","remove_file", SynStr(test_file2))
    chk("remove_file ok",        lambda rr=rr: isinstance(rr, SynOk))
    chk("file gone after remove",lambda: call("io","file_exists",SynStr(test_file2)) == SYN_FALSE)

    # Env
    chk("env_var_or default",    lambda: call("io","env_var_or",SynStr("__NOSUCHVAR__"),SynStr("default")).value == "default")
    chk("cwd returns str",       lambda: isinstance(call("io","cwd"), SynStr))
    chk("home returns str",      lambda: isinstance(call("io","home"), SynStr))

    # Temp
    tf = call("io","temp_file",SynStr(".tmp"))
    chk("temp_file ok",          lambda tf=tf: isinstance(tf, SynOk))
    if isinstance(tf, SynOk) and os.path.exists(tf.value.value):
        os.unlink(tf.value.value)
    td = call("io","temp_dir")
    chk("temp_dir ok",           lambda td=td: isinstance(td, SynOk))
    if isinstance(td, SynOk) and os.path.isdir(td.value.value):
        import shutil; shutil.rmtree(td.value.value)

# ════════════════════════════════════════════════════════
print("\n-- var::tensor --")
# ════════════════════════════════════════════════════════

def T(*shape): return SynArray([SynInt(d) for d in shape])
def Ts(arr):   return _from_np(np.array(arr, dtype=np.float64))

# Creation
chk("zeros shape",   lambda: call("tensor","zeros",T(3,4)).shape == (3,4))
chk("ones sum",      lambda: abs(call("tensor","sum",call("tensor","ones",T(5))).value - 5.0) < 1e-9)
chk("arange len",    lambda: len(_to_np(call("tensor","arange",SynInt(0),SynInt(10),SynInt(2)))) == 5)
chk("linspace len",  lambda: len(_to_np(call("tensor","linspace",SynFloat(0.0),SynFloat(1.0),SynInt(11)))) == 11)
chk("rand shape",    lambda: call("tensor","rand",T(3,4)).shape == (3,4))
chk("randn shape",   lambda: call("tensor","randn",T(100,)).shape == (100,))
chk("from_list",     lambda: len(_to_np(call("tensor","from_list",SynArray([SynFloat(1.0),SynFloat(2.0),SynFloat(3.0)])))) == 3)
chk("eye 3x3",       lambda: call("tensor","eye",SynInt(3)).shape == (3,3))

# Shape ops
t_2x3 = call("tensor","zeros",T(2,3))
chk("shape returns",    lambda: call("tensor","shape",t_2x3).elements[0].value == 2)
chk("rank 2d",          lambda: call("tensor","rank",t_2x3).value == 2)
chk("numel 2x3=6",      lambda: call("tensor","numel",t_2x3).value == 6)
chk("reshape",          lambda: call("tensor","reshape",t_2x3,T(3,2)).shape == (3,2))
chk("flatten",          lambda: call("tensor","flatten",t_2x3).shape == (6,))
chk("transpose",        lambda: call("tensor","transpose",t_2x3).shape == (3,2))
chk("squeeze",          lambda: call("tensor","squeeze",call("tensor","zeros",T(1,3,1))).shape == (3,))

# Arithmetic
a = Ts([1.0,2.0,3.0]); b = Ts([4.0,5.0,6.0])
chk("add",     lambda a=a,b=b: abs(_to_np(call("tensor","add",a,b)).sum() - 21.0) < 1e-9)
chk("sub",     lambda a=a,b=b: abs(_to_np(call("tensor","sub",b,a))[0] - 3.0) < 1e-9)
chk("mul",     lambda a=a,b=b: abs(_to_np(call("tensor","mul",a,b)).sum() - 32.0) < 1e-9)
chk("div",     lambda a=a,b=b: abs(_to_np(call("tensor","div",b,b))[0] - 1.0) < 1e-9)
chk("neg",     lambda a=a: _to_np(call("tensor","neg",a))[0] == -1.0)
chk("abs",     lambda: _to_np(call("tensor","abs",Ts([-1.0,-2.0])))[0] == 1.0)
chk("sqrt",    lambda: abs(float(_to_np(call("tensor","sqrt",Ts([4.0]))) [0]) - 2.0) < 1e-9)
chk("exp",     lambda: abs(float(_to_np(call("tensor","exp",Ts([0.0])))[0]) - 1.0) < 1e-9)
chk("log",     lambda: abs(float(_to_np(call("tensor","log",Ts([math.e])))[0]) - 1.0) < 1e-9)
chk("scale",   lambda a=a: abs(_to_np(call("tensor","scale",a,SynFloat(2.0)))[0] - 2.0) < 1e-9)
chk("clip",    lambda: abs(float(_to_np(call("tensor","clip",Ts([5.0]),SynFloat(0.0),SynFloat(3.0)))[0]) - 3.0) < 1e-9)

# Linear algebra
m = Ts([[1.0,2.0],[3.0,4.0]]); v = Ts([1.0,1.0])
chk("matmul 2x2",  lambda m=m,v=v: call("tensor","matmul",m,_from_np(np.array([[1.0],[1.0]]))).shape == (2,1))
chk("dot product", lambda a=a,b=b: abs(call("tensor","dot",a,b).value - 32.0) < 1e-9)
chk("norm L2",     lambda v=v: abs(call("tensor","norm",v,SynInt(2)).value - math.sqrt(2)) < 1e-9)
chk("det 2x2",     lambda m=m: abs(call("tensor","det",m).value - (-2.0)) < 1e-9)
chk("transpose T", lambda m=m: call("tensor","transpose",m).shape == (2,2))

# Reductions
t5 = Ts([1.0,2.0,3.0,4.0,5.0])
chk("sum",     lambda t5=t5: abs(call("tensor","sum",t5).value - 15.0) < 1e-9)
chk("mean",    lambda t5=t5: abs(call("tensor","mean",t5).value - 3.0) < 1e-9)
chk("min",     lambda t5=t5: abs(call("tensor","min",t5).value - 1.0) < 1e-9)
chk("max",     lambda t5=t5: abs(call("tensor","max",t5).value - 5.0) < 1e-9)
chk("argmin",  lambda t5=t5: call("tensor","argmin",t5).value == 0)
chk("argmax",  lambda t5=t5: call("tensor","argmax",t5).value == 4)
chk("prod",    lambda t5=t5: abs(call("tensor","prod",t5).value - 120.0) < 1e-9)
chk("std",     lambda t5=t5: call("tensor","std",t5).value > 0)
chk("median",  lambda t5=t5: abs(call("tensor","median",t5).value - 3.0) < 1e-9)

# Activations
x = Ts([-1.0, 0.0, 1.0, 2.0])
chk("relu min 0",     lambda x=x: _to_np(call("tensor","relu",x))[0] == 0.0)
chk("relu positive",  lambda x=x: _to_np(call("tensor","relu",x))[-1] == 2.0)
chk("sigmoid range",  lambda x=x: 0 < _to_np(call("tensor","sigmoid",x))[2] < 1)
chk("softmax sums 1", lambda x=x: abs(_to_np(call("tensor","softmax",x)).sum() - 1.0) < 1e-9)
chk("tanh range",     lambda x=x: -1 < _to_np(call("tensor","tanh",x))[0] < 0)

# Normalization
rand_vec = call("tensor","randn",T(10,))
chk("normalize L2=1",  lambda v=rand_vec: abs(call("tensor","norm",call("tensor","normalize",v),SynInt(2)).value - 1.0) < 1e-6)

# Combine / split
c1 = Ts([1.0,2.0,3.0]); c2 = Ts([4.0,5.0,6.0])
chk("concat len 6",    lambda c1=c1,c2=c2: len(_to_np(call("tensor","concat",c1,c2,SynInt(0)))) == 6)
chk("split count 3",   lambda c1=c1: len(call("tensor","split",c1,SynInt(3)).elements) == 3)
chk("stack 2x3",       lambda c1=c1,c2=c2: call("tensor","stack",SynArray([c1,c2]),SynInt(0)).shape == (2,3))

# Distance
u = Ts([1.0,0.0]); v2 = Ts([0.0,1.0])
chk("cosine_sim perp=0",  lambda u=u,v2=v2: abs(call("tensor","cosine_sim",u,v2).value) < 1e-9)
chk("cosine_sim self=1",  lambda u=u: abs(call("tensor","cosine_sim",u,u).value - 1.0) < 1e-9)
chk("l2_dist pythagorean",lambda u=u,v2=v2: abs(call("tensor","l2_dist",u,v2).value - math.sqrt(2)) < 1e-9)

# Top-k
t10 = Ts([3.0,1.0,4.0,1.0,5.0,9.0,2.0,6.0])
chk("top_k[0] is argmax",lambda t10=t10: call("tensor","top_k",t10,SynInt(1)).elements[0].value == int(np.argmax([3,1,4,1,5,9,2,6])))

# Sort
chk("sort ascending",    lambda t5=t5: _to_np(call("tensor","sort",Ts([3.0,1.0,2.0])))[0] == 1.0)

# to_list
tl = call("tensor","to_list",Ts([1.0,2.0,3.0]))
chk("to_list is array",  lambda tl=tl: isinstance(tl, SynArray) and len(tl.elements) == 3)
chk("to_list values",    lambda tl=tl: tl.elements[0].value == 1.0)

# Save / load
with tempfile.NamedTemporaryFile(suffix=".npy", delete=False) as f: npy_path=f.name
try:
    sv = call("tensor","save",Ts([1.0,2.0,3.0]),SynStr(npy_path))
    chk("save ok",       lambda sv=sv: isinstance(sv, SynOk))
    lv = call("tensor","load",SynStr(npy_path))
    chk("load ok",       lambda lv=lv: isinstance(lv, SynOk))
    chk("load values",   lambda lv=lv: abs(_to_np(lv.value)[0] - 1.0) < 1e-9)
finally:
    if os.path.exists(npy_path): os.unlink(npy_path)

# ════════════════════════════════════════════════════════
print("\n-- var::http --")
# ════════════════════════════════════════════════════════

chk("url_encode spaces",  lambda: call("http","url_encode",SynStr("hello world")).value == "hello%20world")
chk("url_decode",         lambda: call("http","url_decode",SynStr("hello%20world")).value == "hello world")

def _test_build_url():
    u = call("http","build_url",SynStr("http://example.com"),SynMap({"q": SynStr("varek")}))
    return "q=varek" in u.value
chk("build_url with params", _test_build_url)

def _test_parse_url():
    p = call("http","parse_url",SynStr("https://example.com:8080/path?q=1"))
    return p.fields["scheme"].value == "https"
chk("parse_url scheme",  _test_parse_url)
chk("parse_url host",    lambda: call("http","parse_url",SynStr("https://api.example.com/v1")).fields["host"].value == "api.example.com")

chk("json_parse valid",  lambda: isinstance(call("http","json_parse",SynStr('{"key": 42}')), SynOk))
chk("json_parse invalid",lambda: isinstance(call("http","json_parse",SynStr("{bad json")), SynErr))
chk("json_format",       lambda: "key" in call("http","json_format",SynStr('{"key":42}')).value)

# NOTE: actual HTTP requests are network-dependent — we skip them here
# but they're tested in examples/http_example.syn

# ════════════════════════════════════════════════════════
print("\n-- var::async --")
# ════════════════════════════════════════════════════════

from varek.stdlib.async_ import _SynChannel, _SynFuture, _SynMutex, _SynSemaphore

chk("channel creates",   lambda: isinstance(call("async_","channel",SynInt(10)), _SynChannel))
chk("channel capacity",  lambda: call("async_","channel",SynInt(5)).ch.capacity == 5)

def _test_send_recv():
    ch = call("async_","channel",SynInt(10))
    s  = call("async_","send",ch,SynInt(42))
    r  = call("async_","recv",ch)
    return isinstance(s,SynOk) and isinstance(r,SynOk) and r.value.value == 42
chk("channel send/recv", _test_send_recv)

def _test_try_recv_empty():
    ch = call("async_","channel",SynInt(5))
    v  = call("async_","try_recv",ch)
    return isinstance(v,SynNil)
chk("try_recv empty=nil",_test_try_recv_empty)

def _test_close():
    ch = call("async_","channel",SynInt(5))
    call("async_","close",ch)
    return call("async_","ch_closed",ch) == SYN_TRUE
chk("close channel",     _test_close)

def _test_spawn_await():
    from varek.runtime import SynBuiltin
    fn = SynBuiltin("add1", lambda args: SynInt(args[0].value + 1))
    f  = call("async_","spawn",fn,SynInt(41))
    r  = call("async_","await_future",f)
    return isinstance(r,SynOk) and r.value.value == 42
chk("spawn + await",     _test_spawn_await)

def _test_parallel_map():
    from varek.runtime import SynBuiltin
    double = SynBuiltin("double", lambda args: SynInt(args[0].value * 2))
    items  = SynArray([SynInt(1),SynInt(2),SynInt(3)])
    result = call("async_","parallel_map",items,double,SynInt(3))
    vals   = sorted(e.value for e in result.elements)
    return vals == [2,4,6]
chk("parallel_map",      _test_parallel_map)

chk("sleep 1ms",         lambda: (call("async_","sleep",SynInt(1)), True)[-1])

chk("mutex creates",     lambda: isinstance(call("async_","mutex"), _SynMutex))
chk("semaphore creates", lambda: isinstance(call("async_","semaphore",SynInt(3)), _SynSemaphore))

def _test_mutex_lock():
    m      = call("async_","mutex")
    shared = [0]
    from varek.runtime import SynBuiltin
    fn = SynBuiltin("inc", lambda args, s=shared: (s.__setitem__(0, s[0]+1), SYN_NIL)[-1])
    call("async_","lock",m,fn)
    call("async_","lock",m,fn)
    return shared[0] == 2
chk("mutex lock fn",     _test_mutex_lock)

def _test_atomic():
    a = call("async_","atomic_int",SynInt(0))
    call("async_","atomic_inc",a,SynInt(5))
    call("async_","atomic_dec",a,SynInt(2))
    return call("async_","atomic_get",a).value == 3
chk("atomic int ops",    _test_atomic)

def _test_select():
    ch1 = call("async_","channel",SynInt(5))
    call("async_","send",ch1,SynStr("ready"))
    r = call("async_","select",SynArray([ch1]))
    return isinstance(r,SynOk) and r.value.value == "ready"
chk("select ready ch",   _test_select)

# ════════════════════════════════════════════════════════
print("\n-- var::pipeline --")
# ════════════════════════════════════════════════════════

from varek.runtime import SynBuiltin, SynFunction

double = SynBuiltin("double", lambda args: SynInt(args[0].value * 2))
inc    = SynBuiltin("inc",    lambda args: SynInt(args[0].value + 1))
steps  = SynArray([double, inc])
source = SynArray([SynInt(1),SynInt(2),SynInt(3)])

def _test_run():
    r = call("pipeline","run",steps,source)
    vals = [e.value for e in r.elements]
    return vals == [3,5,7]   # double then inc: 1->2->3, 2->4->5, 3->6->7
chk("pipeline run",      _test_run)

def _test_run_parallel():
    r = call("pipeline","run_parallel",steps,source,SynInt(2))
    vals = sorted(e.value for e in r.elements)
    return vals == [3,5,7]
chk("run_parallel",      _test_run_parallel)

def _test_map_pipeline():
    r = call("pipeline","map_pipeline",steps,SynInt(5))
    return r.value == 11   # double(5)=10, inc(10)=11
chk("map_pipeline",      _test_map_pipeline)

def _test_chain():
    chained = call("pipeline","chain",double,inc)
    r = chained.impl([SynInt(4)])
    return r.value == 9   # double(4)=8, inc(8)=9
chk("chain combinator",  _test_chain)

def _test_filter_step():
    is_even = SynBuiltin("is_even", lambda args: SynBool(args[0].value % 2 == 0))
    sq      = SynBuiltin("square",  lambda args: SynInt(args[0].value ** 2))
    fs      = call("pipeline","filter_step",is_even,sq)
    # Even numbers get squared, odd pass through
    r_even  = fs.impl([SynInt(4)])
    r_odd   = fs.impl([SynInt(3)])
    return r_even.value == 16 and r_odd.value == 3
chk("filter_step",       _test_filter_step)

def _test_retry():
    attempts = [0]
    def flaky(args, att=attempts):
        att[0] += 1
        if att[0] < 3: raise RuntimeError("not yet")
        return SynInt(42)
    flaky_fn = SynBuiltin("flaky", flaky)
    retried  = call("pipeline","retry",flaky_fn,SynInt(5))
    r        = retried.impl([SynInt(0)])
    return r.value == 42 and attempts[0] == 3
chk("retry on failure",  _test_retry)

def _test_benchmark():
    r = call("pipeline","benchmark",steps,source,SynInt(2))
    return hasattr(r,"fields") and "throughput" in r.fields
chk("benchmark returns stats",_test_benchmark)

def _test_stream_collect():
    r   = call("pipeline","stream",steps,source,SynInt(10))
    out = call("pipeline","collect",r)
    vals = sorted(e.value for e in out.elements)
    return vals == [3,5,7]
chk("stream + collect",  _test_stream_collect)

# ════════════════════════════════════════════════════════
print("\n-- var::model --")
# ════════════════════════════════════════════════════════

def call_m(name, *args): return bi("model",name)(list(args))

chk("linear_model creates",   lambda: hasattr(call_m("linear_model",SynInt(4),SynInt(2)), "weights"))
chk("linear_model in_dim",    lambda: call_m("linear_model",SynInt(4),SynInt(2)).meta["in"] == 4)
chk("embedding creates",      lambda: hasattr(call_m("embedding",SynInt(100),SynInt(16)),"weights"))
chk("embedding shape",        lambda: call_m("embedding",SynInt(100),SynInt(16)).weights[0].shape == (100,16))

def _test_lookup():
    em  = call_m("embedding",SynInt(50),SynInt(8))
    out = call_m("lookup",em,SynArray([SynInt(0),SynInt(1),SynInt(2)]))
    return out.shape == (3,8)
chk("embedding lookup",       _test_lookup)

def _test_infer():
    m = call_m("linear_model",SynInt(4),SynInt(2))
    r = call_m("infer",m,_from_np(np.ones(4)))
    return isinstance(r,SynOk) and r.value.shape == (2,)
chk("model infer",            _test_infer)

def _test_from_weights():
    W  = _from_np(np.eye(3))
    b  = _from_np(np.zeros(3))
    m  = call_m("from_weights",SynArray([W]),SynArray([b]))
    r  = call_m("infer",m,_from_np(np.array([1.0,2.0,3.0])))
    return isinstance(r,SynOk)
chk("from_weights + infer",   _test_from_weights)

def _test_model_io():
    with tempfile.NamedTemporaryFile(suffix=".json",delete=False) as f: p=f.name
    try:
        m  = call_m("linear_model",SynInt(4),SynInt(2))
        sv = call_m("save",m,SynStr(p))
        lv = call_m("load",SynStr(p))
        return isinstance(sv,SynOk) and isinstance(lv,SynOk)
    finally:
        if os.path.exists(p): os.unlink(p)
chk("model save/load",        _test_model_io)

chk("model_info layers",      lambda: call_m("model_info",call_m("linear_model",SynInt(4),SynInt(2))).fields["layers"].value == 1)
chk("list_formats",           lambda: isinstance(call_m("list_formats"), SynArray))

def _test_tokenize():
    vocab = SynMap({"hello":SynInt(5),"world":SynInt(6)})
    r = call_m("tokenize",SynStr("hello world"),vocab)
    return isinstance(r,SynArray) and r.elements[0].value == 5
chk("tokenize with vocab",    _test_tokenize)

chk("bpe_encode list",        lambda: isinstance(call_m("bpe_encode",SynStr("hi")),SynArray))
chk("char_tokenize len",      lambda: len(call_m("char_tokenize",SynStr("hello")).elements) == 5)

# ════════════════════════════════════════════════════════
print("\n-- var::data --")
# ════════════════════════════════════════════════════════

def call_d(name, *args): return bi("data",name)(list(args))

items_10 = SynArray([SynInt(i) for i in range(10)])

chk("shuffle preserves len",  lambda: len(call_d("shuffle",items_10,SynInt(42)).elements) == 10)
chk("shuffle changes order",  lambda: (
    s := call_d("shuffle",items_10,SynInt(99)),
    any(s.elements[i].value != i for i in range(10))
)[-1])

def _test_split():
    r = call_d("split_train_test",items_10,SynFloat(0.8))
    return len(r.elements[0].elements) == 8 and len(r.elements[1].elements) == 2
chk("train_test split 80/20", _test_split)

def _test_batch():
    b = call_d("batch",items_10,SynInt(3))
    return isinstance(b,SynArray) and len(b.elements) == 4  # ceil(10/3)
chk("batch 10 items size 3",  _test_batch)

def _test_flatten():
    b = call_d("batch",items_10,SynInt(5))
    f = call_d("flatten_batches",b)
    return len(f.elements) == 10
chk("flatten_batches",        _test_flatten)

def _test_one_hot():
    labels = SynArray([SynInt(0),SynInt(2),SynInt(1)])
    r = call_d("one_hot",labels,SynInt(3))
    arr = _to_np(r)
    return arr.shape == (3,3) and arr[0,0] == 1.0 and arr[1,2] == 1.0
chk("one_hot encoding",       _test_one_hot)

def _test_train_test_split():
    X = _from_np(np.arange(20,dtype=float).reshape(10,2))
    y = _from_np(np.arange(10,dtype=float))
    r = call_d("train_test_split",X,y,SynFloat(0.7))
    return len(r.elements) == 4 and _to_np(r.elements[0]).shape[0] == 7
chk("train_test_split tensor",_test_train_test_split)

def _test_normalize():
    data = _from_np(np.array([1.0,2.0,3.0,4.0,5.0]))
    norm = call_d("normalize_dataset",data)
    arr  = _to_np(norm)
    return abs(arr.mean()) < 1e-9 and abs(arr.std() - 1.0) < 1e-9
chk("normalize_dataset",      _test_normalize)

def _test_kfold():
    X = _from_np(np.arange(10,dtype=float))
    r = call_d("kfold",X,SynInt(5))
    return len(r.elements) == 5
chk("kfold 5 folds",          _test_kfold)

def _test_augment():
    t  = _from_np(np.ones((2,4,4)))
    t2 = call_d("augment_noise",t,SynFloat(0.1))
    return not np.allclose(_to_np(t), _to_np(t2))
chk("augment_noise changes",  _test_augment)

def _test_vocab():
    texts  = SynArray([SynStr("hello world"),SynStr("hello varek"),SynStr("world varek")])
    vocab  = call_d("vocab_from_corpus",texts,SynInt(100))
    return isinstance(vocab,SynMap) and "hello" in vocab.entries
chk("vocab_from_corpus",      _test_vocab)

def _test_encode_texts():
    texts = SynArray([SynStr("hello world"),SynStr("hello")])
    vocab = SynMap({"hello":SynInt(4),"world":SynInt(5),"<PAD>":SynInt(0),"<UNK>":SynInt(1),"<BOS>":SynInt(2),"<EOS>":SynInt(3)})
    r     = call_d("encode_texts",texts,vocab,SynInt(5))
    arr   = _to_np(r)
    return arr.shape == (2,5) and arr[0,0] == 4.0
chk("encode_texts",           _test_encode_texts)

def _test_sliding_window():
    seq = SynArray([SynInt(i) for i in range(6)])
    r   = call_d("sliding_window",seq,SynInt(3),SynInt(1))
    return len(r.elements) == 4
chk("sliding_window",         _test_sliding_window)

# Metrics
pred = SynArray([SynInt(1),SynInt(1),SynInt(0),SynInt(1)])
true = SynArray([SynInt(1),SynInt(0),SynInt(0),SynInt(1)])
chk("accuracy 75%",   lambda: abs(call_d("accuracy",pred,true).value - 0.75) < 1e-9)

p_t = _from_np(np.array([1.0,2.0,3.0])); t_t = _from_np(np.array([1.05,2.05,3.05]))
chk("mse > 0",        lambda p=p_t,t=t_t: call_d("mse",p,t).value > 0)
chk("mae > 0",        lambda p=p_t,t=t_t: call_d("mae",p,t).value > 0)
chk("r2 near 1",      lambda p=p_t,t=t_t: call_d("r2_score",p,t).value > 0.9)

chk("ngrams 2-gram",  lambda: len(call_d("ngrams",SynArray([SynInt(i) for i in range(5)]),SynInt(2)).elements) == 4)

with tempfile.TemporaryDirectory() as d:
    csv_path = os.path.join(d,"test.csv")
    with open(csv_path,"w") as f:
        f.write("x,y,label\n1.0,2.0,cat\n3.0,4.0,dog\n5.0,6.0,cat\n")
    r = call_d("load_csv",SynStr(csv_path))
    chk("load_csv ok",    lambda r=r: isinstance(r,SynOk))
    chk("load_csv rows",  lambda r=r: len(r.value.elements) == 3)

# ════════════════════════════════════════════════════════
print("\n-- End-to-End: Interpreter with stdlib imports --")
# ════════════════════════════════════════════════════════

def _run(src):
    i = Interpreter(); i.run(src); return i

def _eval(src):
    i = Interpreter(); return i.eval_expr(src)

def _test_io_import():
    i = _run("import var::io\nlet exists = io.file_exists(\"/tmp\")")
    return i._global_env.get("exists").value == True
chk("import var::io + use",   _test_io_import)

def _test_tensor_import():
    i = _run("import var::tensor\nlet t = tensor.zeros([3, 4])\nlet s = tensor.shape(t)")
    s = i._global_env.get("s")
    return isinstance(s, SynArray) and s.elements[0].value == 3
chk("import var::tensor + zeros", _test_tensor_import)

def _test_tensor_math():
    i = _run("""
import var::tensor
let a = tensor.from_list([1.0, 2.0, 3.0])
let b = tensor.from_list([4.0, 5.0, 6.0])
let d = tensor.dot(a, b)
""")
    d = i._global_env.get("d")
    return abs(d.value - 32.0) < 1e-9
chk("tensor.dot via interpreter", _test_tensor_math)

def _test_pipeline_import():
    i = _run("""
import var::pipeline as pl
fn double(x: int) -> int { x * 2 }
fn inc(x: int) -> int { x + 1 }
let result = pl.run([double, inc], [1, 2, 3])
""")
    r = i._global_env.get("result")
    vals = sorted(e.value for e in r.elements)
    return vals == [3,5,7]
chk("pipeline.run via interpreter", _test_pipeline_import)

def _test_model_pipeline():
    i = _run("""
import var::tensor
import var::model
let m = model.linear_model(4, 2)
let x = tensor.ones([4])
let r = model.infer(m, x)
""")
    r = i._global_env.get("r")
    return isinstance(r, SynOk) and r.value.shape == (2,)
chk("model.infer via interpreter", _test_model_pipeline)

def _test_async_import():
    i = _run("""
import var::async as aio
let ch = aio.channel(10)
let _ = aio.send(ch, 42)
let v = aio.recv(ch)
""")
    v = i._global_env.get("v")
    return isinstance(v, SynOk) and v.value.value == 42
chk("async channel via interpreter", _test_async_import)

def _test_data_import():
    i = _run("""
import var::data
let items = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
let split = data.split_train_test(items, 0.8)
""")
    s = i._global_env.get("split")
    return isinstance(s, SynArray) and len(s.elements) == 2
chk("data.split via interpreter", _test_data_import)

# ════════════════════════════════════════════════════════
print("\n-- API Surface --")
# ════════════════════════════════════════════════════════

chk("version 0.4.0",     lambda: varek.__version__ == "0.4.0")
chk("author",            lambda: "Kenneth" in varek.__author__)
chk("check() works",     lambda: varek.check("let x = 1").ok)
chk("io total exports",  lambda: len(get_module("io")._exports) >= 35)
chk("tensor total",      lambda: len(get_module("tensor")._exports) >= 100)
chk("http total",        lambda: len(get_module("http")._exports) >= 15)
chk("async total",       lambda: len(get_module("async")._exports) >= 25)
chk("pipeline total",    lambda: len(get_module("pipeline")._exports) >= 12)
chk("model total",       lambda: len(get_module("model")._exports) >= 10)
chk("data total",        lambda: len(get_module("data")._exports) >= 20)

total_fns = sum(len(get_module(m)._exports) for m in ["io","tensor","http","async","pipeline","model","data"])
chk(f"total ≥ 250 fns ({total_fns})", lambda t=total_fns: t >= 250)

# ════════════════════════════════════════════════════════
print(f"\n{'='*56}")
print(f"  {P} passed  |  {F} failed  |  {P+F} total")
print(f"{'='*56}")
if FAILS:
    print("\nFailed:")
    for n,m in FAILS: print(f"  {n}: {m}")
import sys; sys.exit(0 if F==0 else 1)
