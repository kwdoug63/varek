# VAREK — v0.4
### AI Pipeline Programming Language

> *One language. Every stage of the AI pipeline.*

[![License: MIT](https://img.shields.io/badge/License-MIT-00ffe0.svg)](LICENSE)
[![Version](https://img.shields.io/badge/version-0.4.0-7c3aed.svg)]()
[![Tests](https://img.shields.io/badge/tests-182%20passed-22c55e.svg)]()
[![Stdlib](https://img.shields.io/badge/stdlib-261%20functions-f59e0b.svg)]()

---

## What's New in v0.4 — Standard Library

The full runtime surface. Seven modules, 261 exported functions, zero external dependencies (beyond NumPy which ships with every Python environment).

| Module | File | Functions | Description |
|--------|------|-----------|-------------|
| **var::io** | `stdlib/io.py` | 41 | File I/O, paths, streams, stdin/stdout, env, temp files |
| **var::tensor** | `stdlib/tensor.py` | 111 | NumPy-backed tensors: creation, arithmetic, linear algebra, activations, normalization, distance |
| **var::http** | `stdlib/http.py` | 19 | HTTP client (GET/POST/PUT/DELETE), URL ops, JSON, lightweight server |
| **var::async** | `stdlib/async_.py` | 32 | Channels, futures, spawn/await, parallel_map, mutex, semaphore, atomic int, timers |
| **var::pipeline** | `stdlib/pipeline.py` | 15 | Pipeline execution engine: sequential, batched, parallel, streaming, combinators |
| **var::model** | `stdlib/model.py` | 14 | Model creation, inference, save/load, embeddings, tokenization |
| **var::data** | `stdlib/model.py` | 29 | CSV/JSON/JSONL/NPY loading, splits, batching, augmentation, text encoding, metrics |

---

## Quick Start

```bash
git clone https://github.com/varek-lang/varek
cd varek
python varek.py demo
```

---

## Usage

### In VAREK source

```varek
import var::io
import var::tensor
import var::pipeline as pl
import var::model
import var::data
import var::async as aio
import var::http

-- File I/O
let content = io.read_file("data.txt")?
let lines   = io.read_lines("corpus.txt")?
io.write_file("out.txt", "hello VAREK")

-- Tensors
let weights = tensor.randn([768, 256])
let bias    = tensor.zeros([256])
let normed  = tensor.layer_norm(weights)
let scores  = tensor.softmax(tensor.matmul(weights, tensor.transpose(weights)))

-- Pipelines
fn preprocess(x: Tensor) -> Tensor {
  tensor.normalize(tensor.relu(x))
}
fn infer(x: Tensor) -> Tensor {
  tensor.softmax(x)
}
let results = pl.run([preprocess, infer], inputs)
let fast    = pl.run_parallel([preprocess, infer], inputs, 8)

-- Models
let m = model.linear_model(768, 256)
let r = model.infer(m, tensor.randn([768]))?

-- Data
let rows       = data.load_csv("dataset.csv")?
let shuffled   = data.shuffle(rows, 42)
let split      = data.split_train_test(shuffled, 0.8)
let train      = split[0]
let test       = split[1]
let vocab      = data.vocab_from_corpus(texts, 10000)
let encoded    = data.encode_texts(texts, vocab, 128)
let one_hot_y  = data.one_hot(labels, 10)

-- Async / concurrency
let ch = aio.channel(32)
let f  = aio.spawn(heavy_compute_fn)
let v  = aio.await_future(f)?
let r2 = aio.parallel_map(items, process_fn, 8)

-- HTTP
let resp = http.get_text("https://api.example.com/data")?
let body = http.post_json("https://api.example.com/infer", json_body)?
```

### In Python (direct stdlib access)

```python
from varek.stdlib import get_module, resolve_import
from varek.stdlib.tensor import _from_np, _to_np
from varek.runtime import SynInt, SynFloat, SynStr, SynArray
import numpy as np

# Get a module
tensor = get_module("tensor")

# Call functions directly
zeros = tensor.get("zeros").impl
t = zeros([SynArray([SynInt(3), SynInt(4)])])
print(t.shape)   # (3, 4)

softmax = tensor.get("softmax").impl
probs = softmax([_from_np(np.array([1.0, 2.0, 3.0]))])
print(_to_np(probs))   # [0.09, 0.245, 0.665]

# Or via the interpreter
from varek.runtime import Interpreter
i = Interpreter()
i.run("""
import var::tensor
let t    = tensor.randn([100, 256])
let mean = tensor.mean(t)
""")
print(i._global_env.get("mean"))   # SynFloat(~0.0)
```

---

## Module Reference

### var::io — 41 functions
```
read_file       write_file      append_file     read_lines
read_bytes      write_bytes     read_gzip       write_gzip
file_exists     is_file         is_dir          list_dir
list_dir_recursive  make_dir    remove_file     remove_dir
copy_file       move_file       file_size       file_mtime
basename        dirname         join_path       abs_path
stem            extension       parent          with_extension
cwd             home            print           println
eprint          input           stdin_lines     env_var
env_var_or      set_env         args            temp_file
temp_dir
```

### var::tensor — 111 functions
```
Creation:  zeros ones full eye arange linspace rand randn rand_int from_list seed
Shape:     shape rank numel dtype reshape flatten transpose permute squeeze unsqueeze broadcast_to
Arithmetic: add sub mul div pow neg abs sqrt exp log log2 log10 sin cos tanh floor ceil round clip scale
Linear algebra: matmul dot outer norm inv det svd eig solve
Reductions: sum mean std var min max argmin argmax prod cumsum diff any all
Activations: relu sigmoid softmax log_softmax gelu leaky_relu dropout
Normalization: normalize normalize_rows standardize layer_norm batch_norm
Slice/index: slice index gather
Combine: concat stack vstack hstack split chunk
Statistics: median percentile histogram cov corr
Sort/topk: top_k sort argsort
Distance: cosine_sim l2_dist l1_dist
Pooling: pad avg_pool1d max_pool1d
I/O: save load save_txt load_txt
Conversion: to_list to_int_list as_float as_int item equal where
```

### var::http — 19 functions
```
get get_text get_json post post_json post_form put patch delete request download
url_encode url_decode build_url parse_url serve json_parse json_format status_ok
```

### var::async — 32 functions
```
Channels:   channel send recv try_recv close ch_size ch_closed select
Futures:    spawn await_future future_done gather sleep timeout
Parallel:   parallel_map parallel_for batch_process
Mutex:      mutex lock try_lock unlock
Semaphore:  semaphore acquire release
Timer:      timer cancel repeat
Atomic:     atomic_int atomic_get atomic_set atomic_inc atomic_dec
```

### var::pipeline — 15 functions
```
Execution:   run run_batch run_parallel map_pipeline
Combinators: chain chain_all filter_step retry log_step tap map_err cache_step
Analysis:    benchmark
Streaming:   stream collect
```

### var::model — 14 functions
```
Creation:     from_weights linear_model embedding lookup
Inference:    infer batch_infer forward
I/O:          save load model_info list_formats
Tokenization: tokenize char_tokenize bpe_encode
```

### var::data — 29 functions
```
Loading:    load_csv load_json load_jsonl load_npy load_npz
Saving:     save_csv save_json save_npy
Splits:     shuffle split_train_test batch flatten_batches
Tensors:    normalize_dataset one_hot train_test_split kfold
Augmentation: augment_flip augment_noise augment_crop augment_scale
Text:       vocab_from_corpus encode_texts sliding_window ngrams
Metrics:    accuracy mse mae cross_entropy r2_score
```

---

## Architecture

```
VAREK v0.4 Runtime
├── varek/stdlib/
│   ├── __init__.py       ← Module registry + import resolver
│   ├── io.py             ← var::io  (41 fns)
│   ├── tensor.py         ← var::tensor (111 fns, NumPy-backed)
│   ├── http.py           ← var::http (19 fns)
│   ├── async_.py         ← var::async (32 fns)
│   ├── pipeline.py       ← var::pipeline (15 fns)
│   └── model.py          ← var::model + var::data (43 fns)
│
├── varek/runtime.py    ← Patched: stdlib import resolution
│                            import var::X → resolve_import()
│                            obj.field → StdlibModule lookup
│
└── varek/parser.py     ← Patched: keyword tokens in module paths
                             (async, pipeline are valid segments)
```

**Import system:** `import var::tensor` is resolved by the registry to `StdlibModule("tensor", EXPORTS)`. The interpreter binds this as a namespace value. Member access (`tensor.zeros`) dispatches to `StdlibModule.get("zeros")`. No files are loaded until the first import — lazy loading per module.

---

## Roadmap

- [x] **v0.1** — Grammar, lexer, parser
- [x] **v0.2** — Type system + HM inference  
- [x] **v0.3** — LLVM compilation backend
- [x] **v0.4** — Standard library ← *you are here*
- [ ] **v0.5** — Package manager CLI (`varek install` / `varek publish`)
- [ ] **v1.0** — Stable release + community RFC governance

---

## License

MIT — *Kenneth Wayne Douglas, MD*  
*"The language that treats AI pipelines as first-class citizens."*
