"""
tests/test_varek.py
─────────────────────
Comprehensive test suite for the VAREK v0.1 lexer and parser.
Run with:  python -m pytest tests/ -v
"""

import pytest
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from varek.lexer  import Lexer, TT, Token
from varek.parser import Parser
from varek.printer import ASTPrinter
import varek.ast as ast
import varek


# ══════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════

def lex(src: str):
    return Lexer(src).tokenize()

def tok_types(src: str):
    return [t.type for t in lex(src) if t.type != TT.EOF]

def tok_vals(src: str):
    return [t.value for t in lex(src) if t.type != TT.EOF]

def parse(src: str):
    tree, errors = varek.parse(src, "<test>")
    return tree, errors

def parse_ok(src: str):
    tree, errors = parse(src)
    assert not errors.has_errors(), errors.report(src.splitlines())
    return tree

def first_stmt(src: str):
    return parse_ok(src).statements[0]


# ══════════════════════════════════════════════════════════════════
# LEXER TESTS
# ══════════════════════════════════════════════════════════════════

class TestLexerLiterals:

    def test_integer(self):
        assert tok_types("42") == [TT.INT]
        assert tok_vals("42") == [42]

    def test_negative_integer_is_minus_plus_int(self):
        types = tok_types("-42")
        assert types == [TT.MINUS, TT.INT]

    def test_float(self):
        assert tok_types("3.14") == [TT.FLOAT]
        assert tok_vals("3.14") == [3.14]

    def test_float_exponent(self):
        tokens = lex("1e-5")
        assert tokens[0].type == TT.FLOAT
        assert abs(tokens[0].value - 1e-5) < 1e-12

    def test_hex_integer(self):
        tokens = lex("0xFF")
        assert tokens[0].type == TT.INT
        assert tokens[0].value == 255

    def test_binary_integer(self):
        tokens = lex("0b1010")
        assert tokens[0].type == TT.INT
        assert tokens[0].value == 10

    def test_numeric_separator(self):
        tokens = lex("1_000_000")
        assert tokens[0].value == 1000000

    def test_string_double_quote(self):
        tokens = lex('"hello world"')
        assert tokens[0].type == TT.STRING
        assert tokens[0].value == "hello world"

    def test_string_single_quote(self):
        tokens = lex("'varek'")
        assert tokens[0].type == TT.STRING
        assert tokens[0].value == "varek"

    def test_string_escape_sequences(self):
        tokens = lex(r'"line1\nline2\ttab"')
        assert tokens[0].value == "line1\nline2\ttab"

    def test_string_unicode_escape(self):
        tokens = lex(r'"\u{1F600}"')
        assert tokens[0].value == "\U0001F600"

    def test_bool_true(self):
        tokens = lex("true")
        assert tokens[0].type == TT.BOOL
        assert tokens[0].value is True

    def test_bool_false(self):
        tokens = lex("false")
        assert tokens[0].type == TT.BOOL
        assert tokens[0].value is False

    def test_nil(self):
        tokens = lex("nil")
        assert tokens[0].type == TT.NIL
        assert tokens[0].value is None


class TestLexerKeywords:

    def test_all_keywords_recognized(self):
        keywords = [
            ("fn", TT.FN), ("schema", TT.SCHEMA), ("pipeline", TT.PIPELINE),
            ("let", TT.LET), ("mut", TT.MUT), ("if", TT.IF), ("else", TT.ELSE),
            ("match", TT.MATCH), ("for", TT.FOR), ("in", TT.IN),
            ("return", TT.RETURN), ("async", TT.ASYNC), ("await", TT.AWAIT),
            ("safe", TT.SAFE), ("import", TT.IMPORT), ("as", TT.AS),
            ("export", TT.EXPORT), ("and", TT.AND), ("or", TT.OR),
            ("not", TT.NOT),
        ]
        for word, expected_tt in keywords:
            tokens = lex(word)
            assert tokens[0].type == expected_tt, \
                f"'{word}' should be {expected_tt}, got {tokens[0].type}"

    def test_identifier_not_keyword(self):
        tokens = lex("foobar")
        assert tokens[0].type == TT.IDENT
        assert tokens[0].value == "foobar"

    def test_identifier_with_underscore(self):
        tokens = lex("_private_var")
        assert tokens[0].type == TT.IDENT


class TestLexerOperators:

    def test_pipe_forward(self):
        assert tok_types("|>") == [TT.PIPE_FWD]

    def test_arrow(self):
        assert tok_types("->") == [TT.ARROW]

    def test_fat_arrow(self):
        assert tok_types("=>") == [TT.FAT_ARROW]

    def test_scope(self):
        assert tok_types("::") == [TT.SCOPE]

    def test_walrus(self):
        assert tok_types(":=") == [TT.WALRUS]

    def test_eq(self):
        assert tok_types("==") == [TT.EQ]

    def test_neq(self):
        assert tok_types("!=") == [TT.NEQ]

    def test_lte(self):
        assert tok_types("<=") == [TT.LTE]

    def test_gte(self):
        assert tok_types(">=") == [TT.GTE]

    def test_comparison_ops(self):
        types = tok_types("< > <= >= == !=")
        assert types == [TT.LT, TT.GT, TT.LTE, TT.GTE, TT.EQ, TT.NEQ]


class TestLexerComments:

    def test_single_line_comment_ignored(self):
        types = tok_types("42 -- this is a comment\n99")
        assert TT.INT in types
        vals = tok_vals("42 -- this is a comment\n99")
        assert vals == [42, 99]

    def test_multiline_comment_ignored(self):
        src = "1 --- this\nis a\nmultiline comment --- 2"
        vals = tok_vals(src)
        assert vals == [1, 2]


class TestLexerErrors:

    def test_unterminated_string_records_error(self):
        lexer = Lexer('"unterminated')
        lexer.tokenize()
        assert lexer.errors.has_errors()

    def test_invalid_escape_records_error(self):
        lexer = Lexer(r'"bad \q escape"')
        lexer.tokenize()
        assert lexer.errors.has_errors()

    def test_unexpected_character_records_error(self):
        lexer = Lexer("42 @ 99")
        lexer.tokenize()
        assert lexer.errors.has_errors()

    def test_lexer_continues_after_error(self):
        lexer = Lexer("@ 42")
        tokens = lexer.tokenize()
        int_tokens = [t for t in tokens if t.type == TT.INT]
        assert len(int_tokens) == 1
        assert int_tokens[0].value == 42


class TestLexerSpans:

    def test_token_line_column(self):
        tokens = lex("let x = 42")
        assert tokens[0].line == 1
        assert tokens[0].col == 1

    def test_multiline_positions(self):
        src = "let x = 1\nlet y = 2"
        tokens = [t for t in lex(src) if t.type != TT.EOF]
        y_tok = next(t for t in tokens if t.type == TT.IDENT
                     and t.value == "y")
        assert y_tok.line == 2


# ══════════════════════════════════════════════════════════════════
# PARSER TESTS
# ══════════════════════════════════════════════════════════════════

class TestParserImports:

    def test_simple_import(self):
        node = first_stmt("import numpy")
        assert isinstance(node, ast.ImportStmt)
        assert node.path == ["numpy"]
        assert node.alias is None
        assert not node.is_safe

    def test_scoped_import(self):
        node = first_stmt("import python::numpy as np")
        assert node.path == ["python", "numpy"]
        assert node.alias == "np"

    def test_safe_import(self):
        node = first_stmt("safe import rust::tokenizers::Tokenizer")
        assert node.is_safe
        assert node.path == ["rust", "tokenizers", "Tokenizer"]


class TestParserSchema:

    def test_empty_schema(self):
        node = first_stmt("schema Empty {}")
        assert isinstance(node, ast.SchemaDecl)
        assert node.name == "Empty"
        assert node.fields == []

    def test_schema_with_fields(self):
        src = """
        schema ImageInput {
          path:   str,
          label:  str?,
          width:  int,
          height: int
        }
        """
        node = first_stmt(src)
        assert isinstance(node, ast.SchemaDecl)
        assert node.name == "ImageInput"
        assert len(node.fields) == 4
        assert node.fields[0].name == "path"
        assert isinstance(node.fields[0].type_, ast.NamedType)
        assert node.fields[0].type_.name == "str"
        assert not node.fields[0].optional
        assert node.fields[1].optional   # label: str?

    def test_schema_array_field(self):
        src = "schema S { tags: str[] }"
        node = first_stmt(src)
        assert isinstance(node.fields[0].type_, ast.ArrayType)

    def test_schema_optional_field(self):
        src = "schema S { meta: str? }"
        node = first_stmt(src)
        assert node.fields[0].optional


class TestParserPipeline:

    def test_basic_pipeline(self):
        src = """
        pipeline classify {
          source: ImageInput[]
          steps:  [preprocess -> embed -> infer]
          output: ClassResult[]
        }
        """
        node = first_stmt(src)
        assert isinstance(node, ast.PipelineDecl)
        assert node.name == "classify"
        assert node.steps == ["preprocess", "embed", "infer"]
        assert isinstance(node.source_type, ast.ArrayType)
        assert isinstance(node.output_type, ast.ArrayType)

    def test_pipeline_with_config(self):
        src = """
        pipeline p {
          source: str
          steps: [a -> b]
          output: str
          config { batch_size: 32, parallelism: 8 }
        }
        """
        node = first_stmt(src)
        assert node.config is not None
        config_dict = dict(node.config.fields)
        assert config_dict["batch_size"].value == 32
        assert config_dict["parallelism"].value == 8


class TestParserFunctions:

    def test_simple_function(self):
        src = """
        fn add(a: int, b: int) -> int {
          a + b
        }
        """
        node = first_stmt(src)
        assert isinstance(node, ast.FnDecl)
        assert node.name == "add"
        assert len(node.params) == 2
        assert node.params[0].name == "a"
        assert isinstance(node.return_type, ast.NamedType)
        assert node.return_type.name == "int"
        assert not node.is_async
        assert not node.is_export

    def test_async_function(self):
        src = "async fn fetch(url: str) -> str { url }"
        node = first_stmt(src)
        assert node.is_async

    def test_exported_function(self):
        src = "export fn greet(name: str) -> str { name }"
        node = first_stmt(src)
        assert node.is_export

    def test_async_exported_function(self):
        src = "export async fn infer(t: Tensor<float, [768]>) -> str { t }"
        node = first_stmt(src)
        assert node.is_async
        assert node.is_export

    def test_no_params_no_return(self):
        src = "fn noop() { nil }"
        node = first_stmt(src)
        assert node.params == []
        assert node.return_type is None


class TestParserLetStatements:

    def test_simple_let(self):
        node = first_stmt("let x = 42")
        assert isinstance(node, ast.LetStmt)
        assert node.name == "x"
        assert not node.mutable
        assert isinstance(node.value, ast.Literal)
        assert node.value.value == 42

    def test_mutable_let(self):
        node = first_stmt("mut let counter = 0")
        assert node.mutable

    def test_let_with_type_annotation(self):
        node = first_stmt("let name: str = \"varek\"")
        assert isinstance(node.type_ann, ast.NamedType)
        assert node.type_ann.name == "str"

    def test_walrus_assignment(self):
        node = first_stmt("let result := compute()")
        assert isinstance(node, ast.LetStmt)


class TestParserExpressions:

    def test_binary_arithmetic(self):
        tree = parse_ok("let r = 1 + 2 * 3")
        let = tree.statements[0]
        # 1 + (2 * 3) — mul binds tighter
        add = let.value
        assert isinstance(add, ast.BinaryExpr)
        assert add.op == "+"

    def test_pipe_expression(self):
        tree = parse_ok('let r = "input" |> tokenize() |> embed()')
        let = tree.statements[0]
        pipe2 = let.value
        assert isinstance(pipe2, ast.PipeExpr)
        pipe1 = pipe2.left
        assert isinstance(pipe1, ast.PipeExpr)

    def test_member_access(self):
        tree = parse_ok("let n = img.path")
        let = tree.statements[0]
        assert isinstance(let.value, ast.MemberExpr)
        assert let.value.field == "path"

    def test_index_access(self):
        tree = parse_ok("let v = arr[0]")
        let = tree.statements[0]
        assert isinstance(let.value, ast.IndexExpr)

    def test_call_no_args(self):
        tree = parse_ok("let r = compute()")
        let = tree.statements[0]
        assert isinstance(let.value, ast.CallExpr)
        assert let.value.args == []

    def test_call_positional_args(self):
        tree = parse_ok('let r = add(1, 2)')
        let = tree.statements[0]
        call = let.value
        assert len(call.args) == 2
        assert call.args[0].keyword is None

    def test_call_keyword_args(self):
        tree = parse_ok('let r = model.encode(text=s, max_len=512)')
        let = tree.statements[0]
        call = let.value
        assert call.args[0].keyword == "text"
        assert call.args[1].keyword == "max_len"

    def test_propagate_operator(self):
        tree = parse_ok("let r = load_model(path)?")
        let = tree.statements[0]
        assert isinstance(let.value, ast.PropagateExpr)

    def test_await_expression(self):
        tree = parse_ok("let r = await fetch(url)")
        let = tree.statements[0]
        assert isinstance(let.value, ast.AwaitExpr)

    def test_array_literal(self):
        tree = parse_ok("let a = [1, 2, 3]")
        let = tree.statements[0]
        arr = let.value
        assert isinstance(arr, ast.ArrayLiteral)
        assert len(arr.elements) == 3

    def test_if_expression(self):
        src = """
        let r = if x > 0 { 1 } else { 0 }
        """
        tree = parse_ok(src)
        let = tree.statements[0]
        assert isinstance(let.value, ast.IfExpr)
        assert let.value.else_branch is not None

    def test_match_expression(self):
        src = """
        match status {
          "ok"  => 1,
          "err" => 0,
          _     => -1
        }
        """
        tree = parse_ok(src)
        stmt = tree.statements[0]
        match = stmt.expr
        assert isinstance(match, ast.MatchExpr)
        assert len(match.arms) == 3
        assert isinstance(match.arms[2].pattern, ast.WildcardPattern)

    def test_for_expression(self):
        src = "for item in dataset { process(item) }"
        tree = parse_ok(src)
        stmt = tree.statements[0]
        for_expr = stmt.expr
        assert isinstance(for_expr, ast.ForExpr)
        assert for_expr.var == "item"

    def test_comparison_operators(self):
        for op in ["==", "!=", "<", ">", "<=", ">="]:
            src = f"let r = a {op} b"
            tree = parse_ok(src)
            binexpr = tree.statements[0].value
            assert isinstance(binexpr, ast.BinaryExpr)
            assert binexpr.op == op

    def test_boolean_operators(self):
        tree = parse_ok("let r = a and b or c")
        let = tree.statements[0]
        # 'and' binds tighter: (a and b) or c
        assert isinstance(let.value, ast.BinaryExpr)
        assert let.value.op == "or"

    def test_unary_minus(self):
        tree = parse_ok("let r = -42")
        let = tree.statements[0]
        # The parser should produce a UnaryExpr OR just a negative Literal
        # Accept either:
        assert (
            isinstance(let.value, ast.UnaryExpr) or
            (isinstance(let.value, ast.Literal) and let.value.value == -42)
        )

    def test_tuple_literal(self):
        tree = parse_ok("let t = (1, 2, 3)")
        let = tree.statements[0]
        assert isinstance(let.value, ast.TupleLiteral)
        assert len(let.value.elements) == 3

    def test_nested_member_call(self):
        src = "let r = model.forward(tensor).softmax()"
        tree = parse_ok(src)
        let = tree.statements[0]
        outer_call = let.value
        assert isinstance(outer_call, ast.CallExpr)


class TestParserTypes:

    def test_named_type(self):
        node = first_stmt("schema S { x: int }")
        assert isinstance(node.fields[0].type_, ast.NamedType)
        assert node.fields[0].type_.name == "int"

    def test_optional_type(self):
        node = first_stmt("schema S { x: str? }")
        t = node.fields[0].type_
        assert isinstance(t, ast.OptionalType)
        assert isinstance(t.inner, ast.NamedType)
        assert t.inner.name == "str"

    def test_array_type(self):
        node = first_stmt("schema S { xs: int[] }")
        t = node.fields[0].type_
        assert isinstance(t, ast.ArrayType)
        assert t.element.name == "int"

    def test_optional_array_type(self):
        node = first_stmt("schema S { xs: str[]? }")
        t = node.fields[0].type_
        assert isinstance(t, ast.OptionalType)
        assert isinstance(t.inner, ast.ArrayType)

    def test_result_type(self):
        src = "fn f() -> Result<Model> { nil }"
        node = first_stmt(src)
        assert isinstance(node.return_type, ast.ResultType)

    def test_tensor_type(self):
        src = "fn f(t: Tensor<float, [768, 512]>) -> int { 0 }"
        node = first_stmt(src)
        tensor_t = node.params[0].type_
        assert isinstance(tensor_t, ast.TensorType)
        assert tensor_t.dims == [768, 512]

    def test_map_type(self):
        src = "schema S { meta: {str: float} }"
        node = first_stmt(src)
        t = node.fields[0].type_
        assert isinstance(t, ast.MapType)

    def test_tuple_type(self):
        src = "schema S { coords: (int, int, int) }"
        node = first_stmt(src)
        t = node.fields[0].type_
        assert isinstance(t, ast.TupleType)
        assert len(t.elements) == 3


class TestParserReturnStmt:

    def test_return_with_value(self):
        src = "fn f() -> int { return 42 }"
        node = first_stmt(src)
        ret = node.body.statements[0]
        assert isinstance(ret, ast.ReturnStmt)
        assert ret.value.value == 42

    def test_return_without_value(self):
        src = "fn f() { return }"
        node = first_stmt(src)
        ret = node.body.statements[0]
        assert isinstance(ret, ast.ReturnStmt)
        assert ret.value is None


class TestParserErrors:

    def test_missing_schema_brace(self):
        _, errors = parse("schema S { x: int")
        assert errors.has_errors()

    def test_missing_fn_paren(self):
        _, errors = parse("fn f x: int) -> int { x }")
        assert errors.has_errors()

    def test_multiple_errors_collected(self):
        _, errors = parse("schema  { fn pipeline }")
        assert len(errors) >= 1

    def test_valid_source_no_errors(self):
        src = """
        schema Input { path: str, size: int }
        fn process(i: Input) -> str { i.path }
        """
        _, errors = parse(src)
        assert not errors.has_errors()


class TestParserFullProgram:

    def test_complete_pipeline_program(self):
        src = """
        import python::numpy as np

        schema ImageInput {
          path:   str,
          label:  str?,
          width:  int,
          height: int
        }

        pipeline classify_images {
          source: ImageInput[]
          steps:  [preprocess -> embed -> infer -> postprocess]
          output: ClassificationResult[]
          config { batch_size: 32, parallelism: 8 }
        }

        fn preprocess(img: ImageInput) -> Tensor<float, [3, 224, 224]> {
          load_image(img.path)
            |> resize(224, 224)
            |> normalize(mean=[0.485, 0.456, 0.406])
        }

        async fn infer(tensor: Tensor<float, [3, 224, 224]>) -> ClassificationResult {
          let model = load_model("resnet50.synmodel")?
          model.forward(tensor)
        }

        fn load_model(path: str) -> Result<Model> {
          if not file_exists(path) {
            return Err("not found: " + path)
          }
          Ok(Model.from_file(path))
        }
        """
        tree, errors = parse(src)
        assert not errors.has_errors(), errors.report(src.splitlines())
        assert len(tree.statements) == 6

        import_node = tree.statements[0]
        assert isinstance(import_node, ast.ImportStmt)

        schema_node = tree.statements[1]
        assert isinstance(schema_node, ast.SchemaDecl)
        assert schema_node.name == "ImageInput"

        pipeline_node = tree.statements[2]
        assert isinstance(pipeline_node, ast.PipelineDecl)
        assert pipeline_node.steps == [
            "preprocess", "embed", "infer", "postprocess"
        ]

        preprocess_fn = tree.statements[3]
        assert isinstance(preprocess_fn, ast.FnDecl)
        assert not preprocess_fn.is_async

        infer_fn = tree.statements[4]
        assert isinstance(infer_fn, ast.FnDecl)
        assert infer_fn.is_async

        load_fn = tree.statements[5]
        assert isinstance(load_fn, ast.FnDecl)
        assert isinstance(load_fn.return_type, ast.ResultType)

    def test_ast_printer_runs_without_crash(self):
        src = """
        schema S { x: int }
        fn f(s: S) -> int { s.x }
        """
        tree = parse_ok(src)
        output = ASTPrinter.print(tree)
        assert "SchemaDecl" in output
        assert "FnDecl" in output
        assert len(output) > 0


# ══════════════════════════════════════════════════════════════════
# INTEGRATION
# ══════════════════════════════════════════════════════════════════

class TestIntegration:

    def test_parse_convenience_function(self):
        tree, errors = varek.parse("let x = 42")
        assert not errors.has_errors()
        assert isinstance(tree, ast.Program)

    def test_version_string(self):
        assert varek.__version__ == "0.1.0"

    def test_author(self):
        assert "Kenneth" in varek.__author__

    def test_round_trip_printer(self):
        """Parser + printer should not crash on a rich source file."""
        src = """
        schema Config { name: str, version: str, debug: bool? }

        pipeline embed_docs {
          source: str[]
          steps: [tokenize -> embed -> store]
          output: EmbeddingResult[]
        }

        async fn tokenize(text: str) -> Token[] {
          let tokens = bpe_encode(text)?
          tokens
        }

        fn embed(tokens: Token[]) -> Tensor<float, [768]> {
          let model = load_model("embed.synmodel")?
          model.forward(tokens)
        }

        fn main() -> Result<nil> {
          let docs = load_docs("corpus/")?
          for doc in docs {
            embed_docs(doc)
          }
          Ok(nil)
        }
        """
        tree, errors = varek.parse(src)
        assert not errors.has_errors(), errors.report(src.splitlines())
        rendered = ASTPrinter.print(tree)
        assert "PipelineDecl" in rendered
        assert "FnDecl" in rendered


# ══════════════════════════════════════════════════════════════════
# ENTRY POINT
# ══════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import unittest
    # Run without pytest
    loader = unittest.TestLoader()
    suite  = loader.discover(".", pattern="test_*.py")
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
