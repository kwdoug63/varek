"""
VAREK — AI Pipeline Programming Language
v0.1 — Formal Grammar + Reference Parser

Author : Kenneth Wayne Douglas, MD
License: MIT
"""

from varek.lexer  import Lexer, Token, TT
from varek.parser import Parser
from varek.errors import ErrorBag, VarekError
from varek.printer import ASTPrinter

__version__ = "0.1.0"
__author__  = "Kenneth Wayne Douglas, MD"
__license__ = "MIT"


def parse(source: str, filename: str = "<stdin>"):
    """
    Convenience function: lex + parse a VAREK source string.

    Returns (ast, errors). Check errors.has_errors() before using
    the AST.

    Example:
        tree, errors = varek.parse(source, "main.syn")
        if errors.has_errors():
            print(errors.report(source.splitlines()))
        else:
            print(ASTPrinter.print(tree))
    """
    lexer  = Lexer(source, filename)
    tokens = lexer.tokenize()

    errors = ErrorBag()
    for e in lexer.errors:
        errors.add(e)

    parser = Parser(tokens, filename)
    tree   = parser.parse()

    for e in parser.errors:
        errors.add(e)

    return tree, errors


__all__ = [
    "Lexer", "Token", "TT",
    "Parser",
    "ErrorBag", "VarekError",
    "ASTPrinter",
    "parse",
]
