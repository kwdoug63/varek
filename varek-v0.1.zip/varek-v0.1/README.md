# VAREK — v0.1
### AI Pipeline Programming Language

> *One language. Every stage of the AI pipeline.*

[![License: MIT](https://img.shields.io/badge/License-MIT-00ffe0.svg)](LICENSE)
[![Version](https://img.shields.io/badge/version-0.1.0-7c3aed.svg)]()
[![Status](https://img.shields.io/badge/status-pre--alpha-f59e0b.svg)]()

---

## What is VAREK?

Modern AI/ML pipelines require stitching together Python scripts, YAML configs, JSON schemas, and shell scripts. VAREK replaces all of it with one statically typed, compiled language designed from first principles for the AI engineering era.

**Faster than Python. Safer than C. More expressive than anything in between.**

---

## v0.1 — What's in this release

This is the **foundation release**: formal grammar, complete lexer, and recursive-descent parser.

| Component | File | Description |
|-----------|------|-------------|
| Formal Grammar | `grammar/VAREK.ebnf` | Complete ISO EBNF grammar |
| Errors | `varek/errors.py` | Structured error types with spans |
| Lexer | `varek/lexer.py` | Full tokeniser — all literals, operators, keywords |
| AST | `varek/ast.py` | Complete typed AST node hierarchy + Visitor |
| Parser | `varek/parser.py` | Recursive-descent parser with error recovery |
| Printer | `varek/printer.py` | AST pretty-printer |
| CLI | `varek.py` | `parse`, `check`, `tokens`, `demo` commands |
| Tests | `tests/test_varek.py` | 109-test suite (100% pass) |
| Example | `examples/image_classification.syn` | Full pipeline source |

---

## Quick Start

```bash
# Clone
git clone https://github.com/varek-lang/varek
cd varek

# Run the demo
python varek.py demo

# Check a source file
python varek.py check examples/image_classification.syn

# Print token stream
python varek.py tokens examples/image_classification.syn

# Print AST
python varek.py parse examples/image_classification.syn
```

**Requirements:** Python 3.10+, no external dependencies.

---

## Language Sample

```varek
import python::numpy as np

schema ImageInput {
  path:   str,
  label:  str?,
  width:  int,
  height: int
}

pipeline classify_images {
  source: ImageInput[]
  steps:  [preprocess -> embed -> infer -> postprocess]
  output: ClassificationResult[]
  config { batch_size: 32, parallelism: 8 }
}

fn preprocess(img: ImageInput) -> Tensor<float, [3, 224, 224]> {
  load_image(img.path)
    |> resize(224, 224)
    |> normalize(mean=[0.485, 0.456, 0.406])
}

async fn infer(t: Tensor<float, [3, 224, 224]>) -> ClassificationResult {
  let model = load_model("resnet50.synmodel")?
  model.forward(t)
}

fn load_model(path: str) -> Result<Model> {
  if not file_exists(path) {
    return Err("Model not found: " + path)
  }
  Ok(Model.from_file(path))
}
```

---

## Use the Parser in Python

```python
import varek
from varek.printer import ASTPrinter

source = open("main.syn").read()
tree, errors = varek.parse(source, filename="main.syn")

if errors.has_errors():
    print(errors.report(source.splitlines()))
else:
    print(ASTPrinter.print(tree))
```

---

## Design Principles

| | |
|--|--|
| **Unification** | One file for schema, logic, pipeline, and config |
| **Safety First** | Compile-time memory safety, no silent null errors |
| **AI Nativity** | `Tensor<T, D>`, `pipeline`, `\|>`, async inference — first-class |
| **LLM-Legible** | Deterministic grammar designed for human + AI collaboration |

---

## Roadmap

- [x] **v0.1** — Formal grammar, lexer, recursive-descent parser ← *you are here*
- [ ] **v0.2** — Type system + Hindley-Milner inference engine
- [ ] **v0.3** — LLVM compilation backend
- [ ] **v0.4** — Standard library (`var::io`, `var::tensor`, `var::http`, ...)
- [ ] **v0.5** — Package manager CLI (`varek install` / `varek publish`)
- [ ] **v1.0** — Stable release + community RFC governance

---

## Contributing

VAREK is open source under the MIT License. All contributions welcome:
- Grammar proposals → open a GitHub Discussion
- Bug reports → open an Issue
- Code → open a Pull Request against `main`

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

---

## License

MIT License — free to use, modify, and distribute.

---

*Created by Kenneth Wayne Douglas, MD*  
*"The language that treats AI pipelines as first-class citizens."*
